/**
 * Noor Al-Iman - Audio & Sound Synthesizer Service
 * Manages Quran recitation playback, Adhan audio alerts, and tactile Web Audio feedback for Tasbeeh counters.
 */

class AudioService {
    constructor() {
        this.quranAudio = new Audio();
        this.adhanAudio = new Audio();
        this.audioCtx = null;
        this.soundEnabled = true;

        this.currentSurah = null;
        this.currentAyah = 0;
        this.totalAyahs = 0;
        this.isPlayingQuran = false;
        this.playbackSpeed = 1.0;

        // Callback hooks
        this.onAyahChange = null;
        this.onPlaybackEnd = null;
        this.onPlaybackStateChange = null;

        this.initEventListeners();
    }

    initAudioContext() {
        if (!this.audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.audioCtx = new AudioContext();
            }
        }
        if (this.audioCtx && this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
    }

    initEventListeners() {
        this.quranAudio.addEventListener('ended', () => {
            this.handleAyahEnded();
        });

        this.quranAudio.addEventListener('error', (e) => {
            console.warn('Audio playback error:', e);
            this.handleAyahEnded();
        });

        this.quranAudio.addEventListener('pause', () => {
            if (this.onPlaybackStateChange) this.onPlaybackStateChange(false);
        });

        this.quranAudio.addEventListener('play', () => {
            if (this.onPlaybackStateChange) this.onPlaybackStateChange(true);
        });
    }

    // ==========================================
    // SYNTHESIZED SOUNDS (Web Audio API)
    // ==========================================
    playBeadClick() {
        if (!this.soundEnabled) return;
        try {
            this.initAudioContext();
            if (!this.audioCtx) return;

            let osc = this.audioCtx.createOscillator();
            let gain = this.audioCtx.createGain();

            // Organic subtle wooden bead click sound
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(600, this.audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(120, this.audioCtx.currentTime + 0.04);

            gain.gain.setValueAtTime(0.2, this.audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.04);

            osc.connect(gain);
            gain.connect(this.audioCtx.destination);

            osc.start();
            osc.stop(this.audioCtx.currentTime + 0.05);

            // Subtle vibration feedback
            if (navigator.vibrate) {
                navigator.vibrate(15);
            }
        } catch (e) {
            console.warn('Web Audio bead click error:', e);
        }
    }

    playCompletionChime() {
        if (!this.soundEnabled) return;
        try {
            this.initAudioContext();
            if (!this.audioCtx) return;

            // Harmonious gentle chord for dhikr goal completion
            const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
            notes.forEach((freq, idx) => {
                let osc = this.audioCtx.createOscillator();
                let gain = this.audioCtx.createGain();

                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime + idx * 0.08);

                gain.gain.setValueAtTime(0.12, this.audioCtx.currentTime + idx * 0.08);
                gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + idx * 0.08 + 0.5);

                osc.connect(gain);
                gain.connect(this.audioCtx.destination);

                osc.start(this.audioCtx.currentTime + idx * 0.08);
                osc.stop(this.audioCtx.currentTime + idx * 0.08 + 0.55);
            });

            if (navigator.vibrate) {
                navigator.vibrate([30, 40, 50]);
            }
        } catch (e) {
            console.warn('Completion chime error:', e);
        }
    }

    // ==========================================
    // QURAN AUDIO RECITATION
    // ==========================================
    playSurah(surahNumber, totalAyahs, startAyah = 1, reciterId = null) {
        this.currentSurah = surahNumber;
        this.totalAyahs = totalAyahs;
        this.currentAyah = startAyah;
        this.isPlayingQuran = true;
        this.playCurrentAyah(reciterId);
    }

    playCurrentAyah(reciterId = null) {
        if (!this.currentSurah || this.currentAyah > this.totalAyahs) {
            this.stopQuran();
            return;
        }

        let url = window.QuranEngine.getAyahAudioUrl(this.currentSurah, this.currentAyah, reciterId);
        this.quranAudio.src = url;
        this.quranAudio.playbackRate = this.playbackSpeed;
        this.quranAudio.play().catch(err => {
            console.warn(`Could not play ayah ${this.currentAyah}:`, err);
        });

        if (this.onAyahChange) {
            this.onAyahChange(this.currentSurah, this.currentAyah);
        }
    }

    handleAyahEnded() {
        if (!this.isPlayingQuran) return;

        if (this.currentAyah < this.totalAyahs) {
            this.currentAyah++;
            this.playCurrentAyah();
        } else {
            this.isPlayingQuran = false;
            if (this.onPlaybackEnd) this.onPlaybackEnd(this.currentSurah);
            if (this.onPlaybackStateChange) this.onPlaybackStateChange(false);
        }
    }

    pauseQuran() {
        this.isPlayingQuran = false;
        this.quranAudio.pause();
        if (this.onPlaybackStateChange) this.onPlaybackStateChange(false);
    }

    resumeQuran() {
        if (this.currentSurah && this.currentAyah) {
            this.isPlayingQuran = true;
            this.quranAudio.play().catch(e => console.warn(e));
            if (this.onPlaybackStateChange) this.onPlaybackStateChange(true);
        }
    }

    nextAyah() {
        if (this.currentAyah < this.totalAyahs) {
            this.currentAyah++;
            this.playCurrentAyah();
        }
    }

    prevAyah() {
        if (this.currentAyah > 1) {
            this.currentAyah--;
            this.playCurrentAyah();
        }
    }

    stopQuran() {
        this.isPlayingQuran = false;
        this.quranAudio.pause();
        this.quranAudio.currentTime = 0;
        this.currentSurah = null;
        this.currentAyah = 0;
        if (this.onPlaybackStateChange) this.onPlaybackStateChange(false);
    }

    setPlaybackSpeed(speed) {
        this.playbackSpeed = speed;
        this.quranAudio.playbackRate = speed;
    }

    // ==========================================
    // ADHAN AUDIO PLAYBACK
    // ==========================================
    playAdhan(source = 'makkah') {
        const adhanUrls = {
            makkah: 'https://cdn.aladhan.com/audio/adhans/makkah.mp3',
            madinah: 'https://cdn.aladhan.com/audio/adhans/madina.mp3',
            mishary: 'https://cdn.aladhan.com/audio/adhans/alafasy.mp3'
        };

        let url = adhanUrls[source] || adhanUrls.makkah;
        this.adhanAudio.src = url;
        this.adhanAudio.volume = 0.9;
        return this.adhanAudio.play().catch(err => {
            console.warn('Adhan stream play blocked or failed:', err);
            // Fallback harmonic chime if external audio stream is restricted
            this.playCompletionChime();
        });
    }

    stopAdhan() {
        this.adhanAudio.pause();
        this.adhanAudio.currentTime = 0;
    }
}

window.AppAudio = new AudioService();

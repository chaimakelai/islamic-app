/**
 * Noor Al-Iman - Main Application Controller
 * Handles UI interactions, prayer timers, adhkar counters, Quran reader & persistent state.
 */

class IslamicApp {
    constructor() {
        this.activeTab = 'prayers';
        this.adhkarCategory = 'morning';
        this.lang = localStorage.getItem('noor_lang') || 'ar';
        this.theme = localStorage.getItem('noor_theme') || 'dark';

        // Prayer settings
        this.selectedCityId = localStorage.getItem('noor_city') || 'cairo';
        this.customLocation = JSON.parse(localStorage.getItem('noor_custom_loc') || 'null');
        this.calcMethod = localStorage.getItem('noor_method') || 'MWL';
        this.asrSchool = localStorage.getItem('noor_asr') || 'standard';
        this.adhanSound = localStorage.getItem('noor_adhan_sound') || 'makkah';
        this.adhanAlerts = localStorage.getItem('noor_adhan_alerts') === 'true';

        // Adhkar state
        this.adhkarProgress = JSON.parse(localStorage.getItem('noor_adhkar_prog') || '{}');

        // Quran state
        this.selectedSurah = null;
        this.surahData = null;
        this.quranFontSize = parseInt(localStorage.getItem('noor_quran_font') || '26', 10);
        this.showTranslation = localStorage.getItem('noor_show_trans') !== 'false';
        this.quranFilter = 'all';

        // Tasbeeh state
        this.tasbeehCount = parseInt(localStorage.getItem('noor_tasbeeh_count') || '0', 10);
        this.tasbeehTotal = parseInt(localStorage.getItem('noor_tasbeeh_total') || '0', 10);
        this.tasbeehPresetIdx = parseInt(localStorage.getItem('noor_tasbeeh_preset') || '0', 10);

        // Prayer times cache
        this.todayPrayerTimes = null;
        this.lastCheckedMinute = null;

        this.init();
    }

    init() {
        this.applyTheme(this.theme);
        this.applyLanguage(this.lang);
        this.bindEvents();
        this.initPrayerEngine();
        this.renderAdhkar();
        this.renderSurahList();
        this.renderTasbeeh();
        this.renderQibla();
        this.initAudioHooks();

        // Start 1-second prayer countdown & time ticker
        setInterval(() => this.updatePrayerTicker(), 1000);
        this.updatePrayerTicker();
    }

    // ==========================================
    // THEME & LANGUAGE
    // ==========================================
    applyTheme(theme) {
        this.theme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('noor_theme', theme);
        const icon = document.getElementById('theme-toggle-icon');
        if (icon) {
            icon.className = theme === 'dark' ? 'fas fa-sun text-amber-400' : 'fas fa-moon text-emerald-700';
        }
    }

    toggleTheme() {
        this.applyTheme(this.theme === 'dark' ? 'light' : 'dark');
    }

    applyLanguage(lang) {
        this.lang = lang;
        localStorage.setItem('noor_lang', lang);
        document.documentElement.setAttribute('lang', lang);
        document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');

        // Update UI text labels with data-i18n
        document.querySelectorAll('[data-i18n]').forEach(el => {
            let key = el.getAttribute('data-i18n');
            if (I18N_STRINGS[this.lang] && I18N_STRINGS[this.lang][key]) {
                el.textContent = I18N_STRINGS[this.lang][key];
            }
        });

        // Re-render views to reflect language
        this.renderPrayerTimes();
        this.renderAdhkar();
        this.renderSurahList();
        this.renderTasbeeh();
        this.renderQibla();
    }

    toggleLanguage() {
        this.applyLanguage(this.lang === 'ar' ? 'en' : 'ar');
    }

    // ==========================================
    // TAB NAVIGATION
    // ==========================================
    switchTab(tabId) {
        this.activeTab = tabId;
        document.querySelectorAll('.tab-content').forEach(el => {
            el.classList.add('hidden');
        });

        const target = document.getElementById(`tab-${tabId}`);
        if (target) {
            target.classList.remove('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // Update navigation bar active states
        document.querySelectorAll('.nav-btn').forEach(btn => {
            let t = btn.getAttribute('data-tab');
            if (t === tabId) {
                btn.classList.add('text-emerald-500', 'font-bold');
                btn.classList.remove('text-gray-400', 'text-slate-400');
            } else {
                btn.classList.remove('text-emerald-500', 'font-bold');
                btn.classList.add('text-gray-400');
            }
        });

        if (tabId === 'qibla') {
            this.renderQibla();
        }
    }

    // ==========================================
    // PRAYER TIMES ENGINE
    // ==========================================
    getLocationCoordinates() {
        if (this.customLocation) {
            return this.customLocation;
        }
        let city = window.PrayerTimesCalc.cities.find(c => c.id === this.selectedCityId);
        if (city) {
            return {
                lat: city.lat,
                lng: city.lng,
                tz: city.tz,
                nameAr: city.nameAr,
                nameEn: city.nameEn,
                country: city.country
            };
        }
        // Default to Cairo
        return { lat: 30.0444, lng: 31.2357, tz: 2, nameAr: 'القاهرة', nameEn: 'Cairo', country: 'Egypt' };
    }

    initPrayerEngine() {
        this.populateCitySelector();
        this.calculateTodayPrayers();
        this.renderPrayerTimes();
    }

    populateCitySelector() {
        const select = document.getElementById('city-select');
        if (!select) return;

        select.innerHTML = '';
        window.PrayerTimesCalc.cities.forEach(city => {
            const opt = document.createElement('option');
            opt.value = city.id;
            opt.textContent = this.lang === 'ar' ? `${city.nameAr} (${city.country})` : `${city.nameEn} (${city.country})`;
            if (city.id === this.selectedCityId && !this.customLocation) {
                opt.selected = true;
            }
            select.appendChild(opt);
        });

        if (this.customLocation) {
            const opt = document.createElement('option');
            opt.value = 'custom';
            opt.textContent = this.lang === 'ar' ? '📍 موقعي الحالي (GPS)' : '📍 My Current Location (GPS)';
            opt.selected = true;
            select.insertBefore(opt, select.firstChild);
        }
    }

    calculateTodayPrayers() {
        const loc = this.getLocationCoordinates();
        const now = new Date();
        this.todayPrayerTimes = window.PrayerTimesCalc.calculatePrayerTimes(
            now,
            loc.lat,
            loc.lng,
            loc.tz,
            this.calcMethod,
            this.asrSchool
        );
    }

    updatePrayerTicker() {
        const now = new Date();

        // Check if date rolled over to recalculate
        if (!this.todayPrayerTimes || this.todayPrayerTimes.fajr.date.getDate() !== now.getDate()) {
            this.calculateTodayPrayers();
            this.renderPrayerTimes();
        }

        const times = this.todayPrayerTimes;
        const info = window.PrayerTimesCalc.getNextPrayer(times, now);

        // Update live digital clock
        const clockEl = document.getElementById('live-clock');
        if (clockEl) {
            let h = String(now.getHours()).padStart(2, '0');
            let m = String(now.getMinutes()).padStart(2, '0');
            let s = String(now.getSeconds()).padStart(2, '0');
            clockEl.textContent = `${h}:${m}:${s}`;
        }

        // Update Next Prayer Countdown
        const nextPrayerNameEl = document.getElementById('next-prayer-name');
        const nextPrayerCountEl = document.getElementById('next-prayer-countdown');
        if (nextPrayerNameEl && info.next) {
            nextPrayerNameEl.textContent = this.lang === 'ar' ? info.next.nameAr : info.next.nameEn;
        }
        if (nextPrayerCountEl) {
            nextPrayerCountEl.textContent = info.countdownStr;
        }

        // Update Desktop Tray Tooltip if running in Electron
        if (window.desktopAPI && info.next) {
            let pName = this.lang === 'ar' ? info.next.nameAr : info.next.nameEn;
            window.desktopAPI.updateTrayStatus(`${pName} (${info.countdownStr})`);
        }

        // Highlight active prayer card
        document.querySelectorAll('.prayer-card').forEach(card => {
            let pKey = card.getAttribute('data-prayer');
            if (info.current && pKey === info.current.key) {
                card.classList.add('active-prayer-card');
            } else {
                card.classList.remove('active-prayer-card');
            }
        });

        // Trigger Adhan alert at exact prayer start minute if enabled
        let currentMinuteKey = `${now.getHours()}:${now.getMinutes()}`;
        if (this.adhanAlerts && this.lastCheckedMinute !== currentMinuteKey) {
            this.lastCheckedMinute = currentMinuteKey;
            this.checkAndTriggerAdhan(times, now);
        }
    }

    checkAndTriggerAdhan(times, now) {
        const prayersToCheck = [
            { key: 'fajr', time: times.fajr.date, nameAr: 'صلاة الفجر', nameEn: 'Fajr Prayer' },
            { key: 'dhuhr', time: times.dhuhr.date, nameAr: 'صلاة الظهر', nameEn: 'Dhuhr Prayer' },
            { key: 'asr', time: times.asr.date, nameAr: 'صلاة العصر', nameEn: 'Asr Prayer' },
            { key: 'maghrib', time: times.maghrib.date, nameAr: 'صلاة المغرب', nameEn: 'Maghrib Prayer' },
            { key: 'isha', time: times.isha.date, nameAr: 'صلاة العشاء', nameEn: 'Isha Prayer' }
        ];

        prayersToCheck.forEach(p => {
            if (p.time.getHours() === now.getHours() && p.time.getMinutes() === now.getMinutes()) {
                window.AppAudio.playAdhan(this.adhanSound);
                this.showBrowserNotification(
                    this.lang === 'ar' ? `حان الآن موعد ${p.nameAr}` : `It is now time for ${p.nameEn}`,
                    this.lang === 'ar' ? 'حي على الصلاة .. حي على الفلاح' : 'Come to prayer .. Come to success'
                );
            }
        });
    }

    showBrowserNotification(title, body) {
        if (window.desktopAPI && window.desktopAPI.sendNotification) {
            window.desktopAPI.sendNotification(title, body);
            return;
        }
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(title, {
                body: body,
                icon: 'assets/icon-192.png'
            });
        }
    }

    renderPrayerTimes() {
        if (!this.todayPrayerTimes) this.calculateTodayPrayers();
        const times = this.todayPrayerTimes;
        const loc = this.getLocationCoordinates();
        const hijri = window.PrayerTimesCalc.getHijriDate(new Date());

        // Update Location Title
        const locTitle = document.getElementById('prayer-location-title');
        if (locTitle) {
            locTitle.textContent = this.lang === 'ar' ? `${loc.nameAr} - ${loc.country}` : `${loc.nameEn}, ${loc.country}`;
        }

        // Update Hijri Date
        const hijriEl = document.getElementById('prayer-hijri-date');
        if (hijriEl) {
            hijriEl.textContent = this.lang === 'ar' ? hijri.formattedAr : hijri.formattedEn;
        }

        // Update Gregorian Date
        const gregEl = document.getElementById('prayer-gregorian-date');
        if (gregEl) {
            let options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            gregEl.textContent = new Date().toLocaleDateString(this.lang === 'ar' ? 'ar-EG' : 'en-US', options);
        }

        // Update prayer cards values
        const prayers = [
            { key: 'fajr', time: times.fajr, icon: 'fa-cloud-sun' },
            { key: 'sunrise', time: times.sunrise, icon: 'fa-sun' },
            { key: 'dhuhr', time: times.dhuhr, icon: 'fa-sun' },
            { key: 'asr', time: times.asr, icon: 'fa-cloud-sun' },
            { key: 'maghrib', time: times.maghrib, icon: 'fa-cloud-meatball' },
            { key: 'isha', time: times.isha, icon: 'fa-moon' }
        ];

        prayers.forEach(p => {
            const timeEl = document.getElementById(`time-${p.key}`);
            if (timeEl) {
                timeEl.textContent = this.lang === 'ar' ? p.time.time12Ar : p.time.time12;
            }
        });
    }

    // ==========================================
    // ADHKAR ENGINE
    // ==========================================
    switchAdhkarCategory(catId) {
        this.adhkarCategory = catId;
        document.querySelectorAll('.adhkar-cat-btn').forEach(btn => {
            let c = btn.getAttribute('data-cat');
            if (c === catId) {
                btn.classList.add('bg-emerald-600', 'text-white', 'shadow-md');
                btn.classList.remove('bg-gray-100', 'dark:bg-slate-800', 'text-gray-700', 'dark:text-gray-300');
            } else {
                btn.classList.remove('bg-emerald-600', 'text-white', 'shadow-md');
                btn.classList.add('bg-gray-100', 'dark:bg-slate-800', 'text-gray-700', 'dark:text-gray-300');
            }
        });
        this.renderAdhkar();
    }

    incrementDhikr(dhikrId, targetRepeat) {
        let current = this.adhkarProgress[dhikrId] || 0;
        if (current < targetRepeat) {
            current++;
            this.adhkarProgress[dhikrId] = current;
            localStorage.setItem('noor_adhkar_prog', JSON.stringify(this.adhkarProgress));

            // Sound and haptic feedback
            window.AppAudio.playBeadClick();

            if (current === targetRepeat) {
                window.AppAudio.playCompletionChime();
            }

            this.updateDhikrCardUI(dhikrId, current, targetRepeat);
            this.updateAdhkarCategoryStats();
        }
    }

    resetDhikr(dhikrId) {
        delete this.adhkarProgress[dhikrId];
        localStorage.setItem('noor_adhkar_prog', JSON.stringify(this.adhkarProgress));
        this.renderAdhkar();
    }

    resetAllCurrentCategoryAdhkar() {
        const list = window.ADHKAR_DATA.filter(d => d.category === this.adhkarCategory);
        list.forEach(d => {
            delete this.adhkarProgress[d.id];
        });
        localStorage.setItem('noor_adhkar_prog', JSON.stringify(this.adhkarProgress));
        this.renderAdhkar();
    }

    updateDhikrCardUI(dhikrId, current, target) {
        const card = document.getElementById(`dhikr-card-${dhikrId}`);
        if (!card) return;

        const countNum = card.querySelector('.dhikr-count-num');
        const badge = card.querySelector('.dhikr-status-badge');
        const ring = card.querySelector('.dhikr-ring-circle');

        if (countNum) countNum.textContent = current;

        let pct = Math.min(100, Math.round((current / target) * 100));
        if (ring) {
            const circumference = 2 * Math.PI * 24; // r=24
            const offset = circumference - (pct / 100) * circumference;
            ring.style.strokeDashoffset = offset;
        }

        if (current >= target) {
            card.classList.add('dhikr-card-completed');
            if (badge) {
                badge.className = 'dhikr-status-badge px-3 py-1 rounded-full text-xs font-bold bg-emerald-500 text-white flex items-center gap-1';
                badge.innerHTML = `<i class="fas fa-check-circle"></i> ${this.lang === 'ar' ? 'مكتمل' : 'Completed'}`;
            }
        }
    }

    updateAdhkarCategoryStats() {
        const list = window.ADHKAR_DATA.filter(d => d.category === this.adhkarCategory);
        let completed = 0;
        list.forEach(d => {
            let c = this.adhkarProgress[d.id] || 0;
            if (c >= d.repeat) completed++;
        });

        let pct = list.length > 0 ? Math.round((completed / list.length) * 100) : 0;
        const progressEl = document.getElementById('adhkar-category-progress');
        const countEl = document.getElementById('adhkar-category-count');
        const barEl = document.getElementById('adhkar-category-bar');

        if (progressEl) progressEl.textContent = `${pct}%`;
        if (countEl) {
            countEl.textContent = this.lang === 'ar' ? `${completed} من ${list.length} مكتمل` : `${completed} of ${list.length} completed`;
        }
        if (barEl) barEl.style.width = `${pct}%`;
    }

    renderAdhkar() {
        const container = document.getElementById('adhkar-list-container');
        if (!container) return;

        const list = window.ADHKAR_DATA.filter(d => d.category === this.adhkarCategory);
        container.innerHTML = '';

        list.forEach((item, index) => {
            let currentCount = this.adhkarProgress[item.id] || 0;
            let isCompleted = currentCount >= item.repeat;
            let circumference = 2 * Math.PI * 24;
            let pct = Math.min(100, Math.round((currentCount / item.repeat) * 100));
            let dashOffset = circumference - (pct / 100) * circumference;

            const card = document.createElement('div');
            card.id = `dhikr-card-${item.id}`;
            card.className = `card-elevated rounded-2xl p-6 transition-all duration-300 relative ${isCompleted ? 'dhikr-card-completed' : ''}`;

            card.innerHTML = `
                <div class="flex items-center justify-between mb-4 pb-3 border-b border-gray-100 dark:border-slate-800">
                    <div class="flex items-center gap-3">
                        <span class="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-center text-sm">
                            ${index + 1}
                        </span>
                        <span class="text-xs font-semibold px-2.5 py-1 rounded-md bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300">
                            ${this.lang === 'ar' ? `التكرار: ${item.repeat} مرات` : `Repeat: ${item.repeat}x`}
                        </span>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="dhikr-status-badge px-3 py-1 rounded-full text-xs font-bold ${isCompleted ? 'bg-emerald-500 text-white flex items-center gap-1' : 'bg-gray-100 dark:bg-slate-800 text-gray-500'}">
                            ${isCompleted ? `<i class="fas fa-check-circle"></i> ${this.lang === 'ar' ? 'مكتمل' : 'Completed'}` : (this.lang === 'ar' ? 'قيد الإنجاز' : 'In Progress')}
                        </span>
                        <button onclick="window.App.resetDhikr('${item.id}')" title="${this.lang === 'ar' ? 'إعادة تعيين' : 'Reset'}" class="text-gray-400 hover:text-red-500 p-1.5 rounded-lg transition-colors">
                            <i class="fas fa-redo-alt text-xs"></i>
                        </button>
                    </div>
                </div>

                <!-- Arabic Text -->
                <div class="font-quran text-xl md:text-2xl text-right leading-loose mb-5 text-gray-900 dark:text-gray-100 select-text" dir="rtl">
                    ${item.arabic}
                </div>

                <!-- Transliteration & Translation -->
                <div class="text-sm text-gray-600 dark:text-gray-400 mb-4 bg-gray-50 dark:bg-slate-800/50 p-4 rounded-xl border border-gray-100 dark:border-slate-800/80">
                    <p class="italic mb-2 text-xs text-emerald-700 dark:text-emerald-400 font-medium">${item.transliteration}</p>
                    <p class="leading-relaxed">${item.translation}</p>
                </div>

                <!-- Virtue / Benefit -->
                <div class="text-xs flex items-start gap-2 text-amber-700 dark:text-amber-400/90 mb-5 bg-amber-50/70 dark:bg-amber-950/30 p-3 rounded-lg border border-amber-200/50 dark:border-amber-800/30">
                    <i class="fas fa-gem mt-0.5 text-amber-500"></i>
                    <div>
                        <span class="font-bold">${this.lang === 'ar' ? 'الفضل: ' : 'Virtue: '}</span>
                        <span>${this.lang === 'ar' ? item.benefit : item.benefitEn}</span>
                        <div class="text-[10px] text-gray-400 dark:text-gray-500 mt-1">${item.reference}</div>
                    </div>
                </div>

                <!-- Big Interactive Tap Button -->
                <div class="flex items-center justify-between pt-2">
                    <div class="text-xs text-gray-400">
                        ${this.lang === 'ar' ? 'اضغط في أي مكان على الزر للعد' : 'Tap button to count'}
                    </div>
                    <button onclick="window.App.incrementDhikr('${item.id}', ${item.repeat})" class="relative group cursor-pointer flex items-center gap-3 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold px-6 py-3 rounded-2xl shadow-lg shadow-emerald-700/20 active:scale-95 transition-all">
                        <svg class="w-12 h-12 -ml-2" viewBox="0 0 56 56">
                            <circle cx="28" cy="28" r="24" stroke="rgba(255,255,255,0.2)" stroke-width="4" fill="none" />
                            <circle class="dhikr-ring-circle" cx="28" cy="28" r="24" stroke="#fbbf24" stroke-width="4" fill="none"
                                stroke-dasharray="${circumference}" stroke-dashoffset="${dashOffset}" stroke-linecap="round" />
                        </svg>
                        <div class="text-left">
                            <span class="block text-xs uppercase tracking-wider text-emerald-100">${this.lang === 'ar' ? 'العدد' : 'Count'}</span>
                            <span class="text-xl font-extrabold"><span class="dhikr-count-num">${currentCount}</span> / ${item.repeat}</span>
                        </div>
                        <i class="fas fa-hand-pointer text-emerald-200 ml-2 animate-bounce"></i>
                    </button>
                </div>
            `;

            container.appendChild(card);
        });

        this.updateAdhkarCategoryStats();
    }

    // ==========================================
    // HOLY QURAN ENGINE
    // ==========================================
    renderSurahList() {
        const grid = document.getElementById('surah-grid');
        if (!grid) return;

        let query = (document.getElementById('surah-search-input')?.value || '').toLowerCase().trim();
        let surahs = window.QURAN_SURAHS;

        if (query) {
            surahs = surahs.filter(s => 
                s.nameAr.includes(query) ||
                s.nameEn.toLowerCase().includes(query) ||
                s.meaning.toLowerCase().includes(query) ||
                String(s.number) === query
            );
        }

        if (this.quranFilter === 'meccan') {
            surahs = surahs.filter(s => s.type === 'Meccan');
        } else if (this.quranFilter === 'medinan') {
            surahs = surahs.filter(s => s.type === 'Medinan');
        } else if (this.quranFilter === 'popular') {
            const popularNumbers = [1, 18, 36, 55, 56, 67, 112, 113, 114];
            surahs = surahs.filter(s => popularNumbers.includes(s.number));
        }

        grid.innerHTML = '';
        if (surahs.length === 0) {
            grid.innerHTML = `<div class="col-span-full text-center py-12 text-gray-400">
                <i class="fas fa-book-open text-4xl mb-3 text-gray-300"></i>
                <p>${this.lang === 'ar' ? 'لم يتم العثور على سور مطابقة للبحث' : 'No Surahs found matching your search'}</p>
            </div>`;
            return;
        }

        surahs.forEach(s => {
            const card = document.createElement('div');
            card.className = 'card-elevated rounded-2xl p-5 cursor-pointer hover:border-emerald-500 hover:shadow-lg transition-all group';
            card.onclick = () => this.openSurahReader(s.number);

            card.innerHTML = `
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-bold flex items-center justify-center text-sm border border-emerald-200 dark:border-emerald-800/40 group-hover:scale-105 transition-transform">
                            ${s.number}
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-900 dark:text-white text-base">${s.nameEn}</h4>
                            <p class="text-xs text-gray-500 dark:text-gray-400">${s.meaning} • ${s.ayahs} ${this.lang === 'ar' ? 'آية' : 'Ayahs'}</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="font-quran text-2xl text-emerald-700 dark:text-emerald-400 font-bold">${s.nameAr}</div>
                        <span class="text-[10px] px-2 py-0.5 rounded-full ${s.type === 'Meccan' ? 'bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300' : 'bg-teal-100 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300'}">
                            ${this.lang === 'ar' ? (s.type === 'Meccan' ? 'مكية' : 'مدنية') : s.type}
                        </span>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
    }

    async openSurahReader(surahNumber) {
        this.selectedSurah = surahNumber;
        document.getElementById('quran-index-view')?.classList.add('hidden');
        const readerView = document.getElementById('quran-reader-view');
        if (readerView) readerView.classList.remove('hidden');

        const titleAr = document.getElementById('reader-surah-title-ar');
        const titleEn = document.getElementById('reader-surah-title-en');
        const metaInfo = document.getElementById('reader-surah-meta');
        const versesContainer = document.getElementById('reader-verses-container');

        if (versesContainer) {
            versesContainer.innerHTML = `
                <div class="text-center py-16">
                    <i class="fas fa-circle-notch fa-spin text-4xl text-emerald-500 mb-4"></i>
                    <p class="text-gray-500 dark:text-gray-400">${this.lang === 'ar' ? 'جاري تحميل آيات السورة المباركة...' : 'Loading verses of the Holy Surah...'}</p>
                </div>
            `;
        }

        try {
            const surah = await window.QuranEngine.getSurah(surahNumber);
            this.surahData = surah;

            if (titleAr) titleAr.textContent = surah.nameAr;
            if (titleEn) titleEn.textContent = `${surah.nameEn} (${surah.meaning})`;
            if (metaInfo) {
                metaInfo.textContent = `${this.lang === 'ar' ? (surah.type === 'Meccan' ? 'مكية' : 'مدنية') : surah.type} • ${surah.ayahs} ${this.lang === 'ar' ? 'آيات' : 'Ayahs'}`;
            }

            // Bismillah banner
            const bismillahBanner = document.getElementById('reader-bismillah');
            if (bismillahBanner) {
                bismillahBanner.style.display = surah.bismillah ? 'block' : 'none';
            }

            this.renderVerses(surah.verses);
            this.updateAudioPlayerBarUI();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (err) {
            console.error('Failed to load surah:', err);
            if (versesContainer) {
                versesContainer.innerHTML = `<div class="p-8 text-center text-red-500">
                    <p>${this.lang === 'ar' ? 'حدث خطأ في تحميل السورة. يرجى التحقق من الاتصال بالإنترنت.' : 'Failed to load Surah. Please check your internet connection.'}</p>
                </div>`;
            }
        }
    }

    renderVerses(verses) {
        const container = document.getElementById('reader-verses-container');
        if (!container) return;

        container.innerHTML = '';
        verses.forEach(v => {
            const row = document.createElement('div');
            row.id = `ayah-row-${v.numberInSurah}`;
            row.className = 'ayah-row card-elevated rounded-2xl p-6 mb-4 border border-gray-100 dark:border-slate-800/80 transition-all';

            row.innerHTML = `
                <div class="flex items-center justify-between mb-4 pb-2 border-b border-gray-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <span class="w-8 h-8 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-bold flex items-center justify-center text-xs border border-emerald-200 dark:border-emerald-800/40">
                            ${v.numberInSurah}
                        </span>
                        <button onclick="window.App.playSpecificAyah(${this.selectedSurah}, ${v.numberInSurah})" class="text-gray-400 hover:text-emerald-600 p-1.5 rounded-lg transition-colors" title="${this.lang === 'ar' ? 'استماع للآية' : 'Play Ayah'}">
                            <i class="fas fa-play text-xs"></i>
                        </button>
                        <button onclick="window.App.copyAyahText('${v.arabic.replace(/'/g, "\\'")}', '${v.translation.replace(/'/g, "\\'")}')" class="text-gray-400 hover:text-emerald-600 p-1.5 rounded-lg transition-colors" title="${this.lang === 'ar' ? 'نسخ' : 'Copy'}">
                            <i class="fas fa-copy text-xs"></i>
                        </button>
                    </div>
                    <span class="text-xs text-gray-400">آية ${v.numberInSurah}</span>
                </div>

                <!-- Arabic Ayah Text -->
                <div class="font-quran text-right leading-loose mb-3 text-gray-900 dark:text-gray-100 select-text" dir="rtl" style="font-size: ${this.quranFontSize}px;">
                    ${v.arabic} <span class="text-amber-500 font-bold text-lg select-none">﴿${v.numberInSurah}﴾</span>
                </div>

                <!-- English Translation -->
                <div class="ayah-translation text-sm text-gray-600 dark:text-gray-400 leading-relaxed mt-3 pt-3 border-t border-gray-50 dark:border-slate-800/50 ${this.showTranslation ? '' : 'hidden'}">
                    ${v.translation}
                </div>
            `;
            container.appendChild(row);
        });
    }

    closeSurahReader() {
        document.getElementById('quran-reader-view')?.classList.add('hidden');
        document.getElementById('quran-index-view')?.classList.remove('hidden');
        window.AppAudio.stopQuran();
        this.updateAudioPlayerBarUI();
    }

    changeQuranFontSize(delta) {
        this.quranFontSize = Math.max(18, Math.min(42, this.quranFontSize + delta));
        localStorage.setItem('noor_quran_font', this.quranFontSize);
        document.querySelectorAll('.font-quran').forEach(el => {
            el.style.fontSize = `${this.quranFontSize}px`;
        });
    }

    toggleTranslation() {
        this.showTranslation = !this.showTranslation;
        localStorage.setItem('noor_show_trans', this.showTranslation);
        document.querySelectorAll('.ayah-translation').forEach(el => {
            if (this.showTranslation) el.classList.remove('hidden');
            else el.classList.add('hidden');
        });
    }

    playSpecificAyah(surahNum, ayahNum) {
        if (!this.surahData) return;
        window.AppAudio.playSurah(surahNum, this.surahData.ayahs, ayahNum);
        this.updateAudioPlayerBarUI();
    }

    toggleQuranAudioPlayback() {
        if (!this.selectedSurah || !this.surahData) return;
        if (window.AppAudio.isPlayingQuran) {
            window.AppAudio.pauseQuran();
        } else {
            if (window.AppAudio.currentSurah === this.selectedSurah && window.AppAudio.currentAyah > 0) {
                window.AppAudio.resumeQuran();
            } else {
                window.AppAudio.playSurah(this.selectedSurah, this.surahData.ayahs, 1);
            }
        }
        this.updateAudioPlayerBarUI();
    }

    initAudioHooks() {
        window.AppAudio.onAyahChange = (surah, ayah) => {
            // Highlight active ayah row in reader
            document.querySelectorAll('.ayah-row').forEach(r => r.classList.remove('ayah-active-audio'));
            const activeRow = document.getElementById(`ayah-row-${ayah}`);
            if (activeRow) {
                activeRow.classList.add('ayah-active-audio');
                activeRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }

            // Update bottom player label
            const currentAyahLabel = document.getElementById('player-bar-ayah');
            if (currentAyahLabel) {
                currentAyahLabel.textContent = `${this.lang === 'ar' ? 'الآية' : 'Ayah'} ${ayah} / ${this.surahData ? this.surahData.ayahs : ''}`;
            }
        };

        window.AppAudio.onPlaybackStateChange = (isPlaying) => {
            const playIcon = document.getElementById('player-play-icon');
            const readerPlayIcon = document.getElementById('reader-play-icon');
            if (playIcon) playIcon.className = isPlaying ? 'fas fa-pause' : 'fas fa-play';
            if (readerPlayIcon) readerPlayIcon.className = isPlaying ? 'fas fa-pause' : 'fas fa-play';
        };
    }

    updateAudioPlayerBarUI() {
        const bar = document.getElementById('bottom-audio-player-bar');
        if (!bar) return;

        if (this.selectedSurah && this.surahData) {
            bar.classList.remove('translate-y-full', 'opacity-0', 'pointer-events-none');
            const title = document.getElementById('player-bar-title');
            if (title) title.textContent = `${this.surahData.nameEn} (${this.surahData.nameAr})`;
        } else {
            bar.classList.add('translate-y-full', 'opacity-0', 'pointer-events-none');
        }
    }

    copyAyahText(arabic, translation) {
        let text = `${arabic}\n\n"${translation}"\n[سورة ${this.surahData?.nameAr || ''}]`;
        navigator.clipboard.writeText(text).then(() => {
            this.showToast(this.lang === 'ar' ? 'تم نسخ الآية الكريمة بنجاح' : 'Ayah copied to clipboard');
        });
    }

    showToast(msg) {
        let toast = document.createElement('div');
        toast.className = 'fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white px-5 py-2.5 rounded-full text-sm font-semibold shadow-2xl flex items-center gap-2 animate-bounce';
        toast.innerHTML = `<i class="fas fa-check-circle text-emerald-400"></i> ${msg}`;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2500);
    }

    // ==========================================
    // DIGITAL TASBEEH ENGINE
    // ==========================================
    renderTasbeeh() {
        const countDisplay = document.getElementById('tasbeeh-count-display');
        const totalDisplay = document.getElementById('tasbeeh-total-display');
        const phraseAr = document.getElementById('tasbeeh-phrase-ar');
        const phraseEn = document.getElementById('tasbeeh-phrase-en');
        const meaning = document.getElementById('tasbeeh-phrase-meaning');
        const targetLabel = document.getElementById('tasbeeh-target-label');

        const preset = window.TASBEEH_PRESETS[this.tasbeehPresetIdx] || window.TASBEEH_PRESETS[0];

        if (countDisplay) countDisplay.textContent = this.tasbeehCount;
        if (totalDisplay) totalDisplay.textContent = this.tasbeehTotal;
        if (phraseAr) phraseAr.textContent = preset.textAr;
        if (phraseEn) phraseEn.textContent = preset.textEn;
        if (meaning) meaning.textContent = preset.meaning;
        if (targetLabel) targetLabel.textContent = `${preset.target}`;

        // Update progress ring around tasbeeh button
        const ring = document.getElementById('tasbeeh-big-ring');
        if (ring) {
            let circ = 2 * Math.PI * 95;
            let pct = Math.min(100, (this.tasbeehCount / preset.target) * 100);
            ring.style.strokeDashoffset = circ - (pct / 100) * circ;
        }
    }

    tapTasbeeh() {
        const preset = window.TASBEEH_PRESETS[this.tasbeehPresetIdx] || window.TASBEEH_PRESETS[0];
        this.tasbeehCount++;
        this.tasbeehTotal++;

        localStorage.setItem('noor_tasbeeh_count', this.tasbeehCount);
        localStorage.setItem('noor_tasbeeh_total', this.tasbeehTotal);

        window.AppAudio.playBeadClick();

        if (this.tasbeehCount >= preset.target) {
            window.AppAudio.playCompletionChime();
            this.showToast(this.lang === 'ar' ? `تقبل الله! أتممت ${preset.target} تسبيحة` : `Masha'Allah! Completed ${preset.target} Tasbeeh`);
            this.tasbeehCount = 0; // Loop cycle
        }

        this.renderTasbeeh();
    }

    resetTasbeeh() {
        this.tasbeehCount = 0;
        localStorage.setItem('noor_tasbeeh_count', 0);
        this.renderTasbeeh();
    }

    resetTotalTasbeeh() {
        this.tasbeehCount = 0;
        this.tasbeehTotal = 0;
        localStorage.setItem('noor_tasbeeh_count', 0);
        localStorage.setItem('noor_tasbeeh_total', 0);
        this.renderTasbeeh();
    }

    changeTasbeehPreset(idx) {
        this.tasbeehPresetIdx = idx;
        this.tasbeehCount = 0;
        localStorage.setItem('noor_tasbeeh_preset', idx);
        localStorage.setItem('noor_tasbeeh_count', 0);
        this.renderTasbeeh();
    }

    // ==========================================
    // QIBLA COMPASS ENGINE
    // ==========================================
    renderQibla() {
        const loc = this.getLocationCoordinates();
        const qibla = window.PrayerTimesCalc.calculateQibla(loc.lat, loc.lng);

        const bearingEl = document.getElementById('qibla-bearing-val');
        const distEl = document.getElementById('qibla-distance-val');
        const dirEl = document.getElementById('qibla-direction-val');
        const needle = document.getElementById('qibla-needle');

        if (bearingEl) bearingEl.textContent = `${qibla.bearing}°`;
        if (distEl) distEl.textContent = `${qibla.distanceKm.toLocaleString()} km`;
        if (dirEl) dirEl.textContent = this.lang === 'ar' ? qibla.directionAr : qibla.directionEn;

        if (needle) {
            needle.style.transform = `rotate(${qibla.bearing}deg)`;
        }
    }

    requestGeolocation() {
        if (!navigator.geolocation) {
            alert(this.lang === 'ar' ? 'خاصية تحديد الموقع غير مدعومة في متصفحك' : 'Geolocation is not supported by your browser');
            return;
        }

        this.showToast(this.lang === 'ar' ? 'جاري تحديد إحداثيات موقعك بدقة...' : 'Locating your exact coordinates...');

        navigator.geolocation.getCurrentPosition(
            (pos) => {
                this.customLocation = {
                    lat: pos.coords.latitude,
                    lng: pos.coords.longitude,
                    tz: -new Date().getTimezoneOffset() / 60,
                    nameAr: 'موقعي الحالي',
                    nameEn: 'Current Location',
                    country: 'GPS'
                };
                localStorage.setItem('noor_custom_loc', JSON.stringify(this.customLocation));
                this.initPrayerEngine();
                this.renderQibla();
                this.showToast(this.lang === 'ar' ? 'تم تحديث مواقيت الصلاة والقبلة لموقعك بدقة!' : 'Prayer times & Qibla updated to your exact GPS location!');
            },
            (err) => {
                console.warn('Geolocation error:', err);
                alert(this.lang === 'ar' ? 'تعذر الوصول للموقع. يرجى اختيار مدينتك من القائمة.' : 'Unable to access location. Please pick your city from the list.');
            },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    }

    // ==========================================
    // EVENT BINDINGS
    // ==========================================
    bindEvents() {
        // City selector change
        const citySelect = document.getElementById('city-select');
        if (citySelect) {
            citySelect.addEventListener('change', (e) => {
                if (e.target.value === 'custom') {
                    this.requestGeolocation();
                } else {
                    this.selectedCityId = e.target.value;
                    this.customLocation = null;
                    localStorage.setItem('noor_city', this.selectedCityId);
                    localStorage.removeItem('noor_custom_loc');
                    this.calculateTodayPrayers();
                    this.renderPrayerTimes();
                    this.renderQibla();
                }
            });
        }

        // Calculation method change
        const methodSelect = document.getElementById('method-select');
        if (methodSelect) {
            methodSelect.value = this.calcMethod;
            methodSelect.addEventListener('change', (e) => {
                this.calcMethod = e.target.value;
                localStorage.setItem('noor_method', this.calcMethod);
                this.calculateTodayPrayers();
                this.renderPrayerTimes();
            });
        }

        // Asr School change
        const asrSelect = document.getElementById('asr-select');
        if (asrSelect) {
            asrSelect.value = this.asrSchool;
            asrSelect.addEventListener('change', (e) => {
                this.asrSchool = e.target.value;
                localStorage.setItem('noor_asr', this.asrSchool);
                this.calculateTodayPrayers();
                this.renderPrayerTimes();
            });
        }

        // Adhan audio alerts toggle
        const adhanToggle = document.getElementById('adhan-alerts-toggle');
        if (adhanToggle) {
            adhanToggle.checked = this.adhanAlerts;
            adhanToggle.addEventListener('change', (e) => {
                this.adhanAlerts = e.target.checked;
                localStorage.setItem('noor_adhan_alerts', this.adhanAlerts);
                if (this.adhanAlerts && 'Notification' in window && Notification.permission !== 'granted') {
                    Notification.requestPermission();
                }
            });
        }

        // Surah search input
        const surahSearch = document.getElementById('surah-search-input');
        if (surahSearch) {
            surahSearch.addEventListener('input', () => this.renderSurahList());
        }
    }
}

// Multilingual i18n Dictionary
const I18N_STRINGS = {
    ar: {
        app_title: 'نور الإيمان',
        prayers_tab: 'مواقيت الصلاة',
        adhkar_tab: 'الأذكار',
        quran_tab: 'القرآن الكريم',
        tasbeeh_tab: 'المسبحة',
        qibla_tab: 'القبلة',
        next_prayer: 'الصلاة القادمة',
        fajr: 'الفجر',
        sunrise: 'الشروق',
        dhuhr: 'الظهر',
        asr: 'العصر',
        maghrib: 'المغرب',
        isha: 'العشاء',
        morning_adhkar: 'أذكار الصباح',
        evening_adhkar: 'أذكار المساء',
        sleep_adhkar: 'أذكار النوم',
        search_surah_placeholder: 'ابحث عن سورة بالاسم أو الرقم...',
        all_surahs: 'كل السور (114)',
        popular_surahs: 'سور مختارة',
        meccan: 'مكية',
        medinan: 'مدنية',
        qibla_compass: 'بوصلة القبلة المشرفة',
        bearing: 'الاتجاه الزاوي',
        distance_to_kaaba: 'المسافة إلى الكعبة المشرفة',
        direction: 'الاتجاه الجغرافي',
        tasbeeh_title: 'المسبحة الإلكترونية الذكية',
        tasbeeh_tap_instruction: 'اضغط على الدائرة للبدء بالتسبيح',
        reset: 'إعادة تعيين',
        total_tasbeeh: 'إجمالي التسبيحات'
    },
    en: {
        app_title: 'Noor Al-Iman',
        prayers_tab: 'Prayer Times',
        adhkar_tab: 'Adhkar',
        quran_tab: 'Holy Quran',
        tasbeeh_tab: 'Tasbeeh',
        qibla_tab: 'Qibla',
        next_prayer: 'Next Prayer',
        fajr: 'Fajr',
        sunrise: 'Sunrise',
        dhuhr: 'Dhuhr',
        asr: 'Asr',
        maghrib: 'Maghrib',
        isha: 'Isha',
        morning_adhkar: 'Morning Adhkar',
        evening_adhkar: 'Evening Adhkar',
        sleep_adhkar: 'Before Sleep Adhkar',
        search_surah_placeholder: 'Search Surah by name or number...',
        all_surahs: 'All Surahs (114)',
        popular_surahs: 'Featured Surahs',
        meccan: 'Meccan',
        medinan: 'Medinan',
        qibla_compass: 'Holy Qibla Compass',
        bearing: 'Qibla Bearing',
        distance_to_kaaba: 'Distance to Kaaba',
        direction: 'Direction',
        tasbeeh_title: 'Smart Digital Tasbeeh',
        tasbeeh_tap_instruction: 'Tap the circle to glorify Allah',
        reset: 'Reset',
        total_tasbeeh: 'Total Tasbeeh'
    }
};

window.I18N_STRINGS = I18N_STRINGS;

// Bootstrap on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    window.App = new IslamicApp();
});

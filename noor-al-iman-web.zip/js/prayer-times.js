/**
 * Noor Al-Iman - Prayer Times & Astronomical Engine
 * Accurate offline calculation of Islamic prayer times and Qibla direction.
 */

class PrayerTimesCalculator {
    constructor() {
        // Calculation methods configuration
        this.methods = {
            MWL: { name: 'Muslim World League (رابطة العالم الإسلامي)', fajrAngle: 18, ishaAngle: 17 },
            ISNA: { name: 'Islamic Society of North America (ISNA)', fajrAngle: 15, ishaAngle: 15 },
            Egypt: { name: 'Egyptian General Authority (الهيئة المصرية العامة للمساحة)', fajrAngle: 19.5, ishaAngle: 17.5 },
            Makkah: { name: 'Umm Al-Qura, Makkah (جامعة أم القرى - مكة المكرمة)', fajrAngle: 18.5, ishaInterval: 90 },
            Karachi: { name: 'Univ. of Islamic Sciences, Karachi (جامعة العلوم الإسلامية بكراتشي)', fajrAngle: 18, ishaAngle: 18 },
            France: { name: 'UOIF - France (اتحاد المنظمات الإسلامية في فرنسا)', fajrAngle: 12, ishaAngle: 12 },
            Turkey: { name: 'Diyanet İşleri Başkanlığı - Turkey (رئاسة الشؤون الدينية التركية)', fajrAngle: 18, ishaAngle: 17 },
            Dubai: { name: 'Dubai / UAE (دائرة الشؤون الإسلامية بدبي)', fajrAngle: 18.2, ishaAngle: 18.2 }
        };

        this.currentMethod = 'MWL';
        this.asrMethod = 'standard'; // 'standard' (Shafi, Maliki, Hanbali) or 'hanafi'
        this.dhuhrMinutesOffset = 1; // 1-2 min after solar noon

        // Pre-configured World Cities
        this.cities = [
            { id: 'makkah', nameAr: 'مكة المكرمة', nameEn: 'Makkah', country: 'Saudi Arabia', lat: 21.4225, lng: 39.8262, tz: 3, method: 'Makkah' },
            { id: 'madinah', nameAr: 'المدينة المنورة', nameEn: 'Madinah', country: 'Saudi Arabia', lat: 24.4672, lng: 39.6111, tz: 3, method: 'Makkah' },
            { id: 'riyadh', nameAr: 'الرياض', nameEn: 'Riyadh', country: 'Saudi Arabia', lat: 24.7136, lng: 46.6753, tz: 3, method: 'Makkah' },
            { id: 'jerusalem', nameAr: 'القدس الشريف', nameEn: 'Jerusalem', country: 'Palestine', lat: 31.7683, lng: 35.2137, tz: 2, method: 'MWL' },
            { id: 'cairo', nameAr: 'القاهرة', nameEn: 'Cairo', country: 'Egypt', lat: 30.0444, lng: 31.2357, tz: 2, method: 'Egypt' },
            { id: 'alexandria', nameAr: 'الإسكندرية', nameEn: 'Alexandria', country: 'Egypt', lat: 31.2001, lng: 29.9187, tz: 2, method: 'Egypt' },
            { id: 'casablanca', nameAr: 'الدار البيضاء', nameEn: 'Casablanca', country: 'Morocco', lat: 33.5731, lng: -7.5898, tz: 1, method: 'MWL' },
            { id: 'rabat', nameAr: 'الرباط', nameEn: 'Rabat', country: 'Morocco', lat: 34.0209, lng: -6.8416, tz: 1, method: 'MWL' },
            { id: 'algiers', nameAr: 'الجزائر العاصمة', nameEn: 'Algiers', country: 'Algeria', lat: 36.7538, lng: 3.0588, tz: 1, method: 'MWL' },
            { id: 'tunis', nameAr: 'تونس', nameEn: 'Tunis', country: 'Tunisia', lat: 36.8065, lng: 10.1815, tz: 1, method: 'MWL' },
            { id: 'tripoli', nameAr: 'طرابلس', nameEn: 'Tripoli', country: 'Libya', lat: 32.8872, lng: 13.1913, tz: 2, method: 'MWL' },
            { id: 'dubai', nameAr: 'دبي', nameEn: 'Dubai', country: 'UAE', lat: 25.2048, lng: 55.2708, tz: 4, method: 'Dubai' },
            { id: 'doha', nameAr: 'الدوحة', nameEn: 'Doha', country: 'Qatar', lat: 25.2854, lng: 51.5310, tz: 3, method: 'MWL' },
            { id: 'kuwait', nameAr: 'الكويت', nameEn: 'Kuwait City', country: 'Kuwait', lat: 29.3759, lng: 47.9774, tz: 3, method: 'MWL' },
            { id: 'amman', nameAr: 'عمان', nameEn: 'Amman', country: 'Jordan', lat: 31.9454, lng: 35.9284, tz: 3, method: 'MWL' },
            { id: 'beirut', nameAr: 'بيروت', nameEn: 'Beirut', country: 'Lebanon', lat: 33.8938, lng: 35.5018, tz: 2, method: 'MWL' },
            { id: 'damascus', nameAr: 'دمشق', nameEn: 'Damascus', country: 'Syria', lat: 33.5138, lng: 36.2765, tz: 3, method: 'MWL' },
            { id: 'baghdad', nameAr: 'بغداد', nameEn: 'Baghdad', country: 'Iraq', lat: 33.3152, lng: 44.3661, tz: 3, method: 'MWL' },
            { id: 'istanbul', nameAr: 'إسطنبول', nameEn: 'Istanbul', country: 'Turkey', lat: 41.0082, lng: 28.9784, tz: 3, method: 'Turkey' },
            { id: 'paris', nameAr: 'باريس', nameEn: 'Paris', country: 'France', lat: 48.8566, lng: 2.3522, tz: 1, method: 'France' },
            { id: 'london', nameAr: 'لندن', nameEn: 'London', country: 'United Kingdom', lat: 51.5074, lng: -0.1278, tz: 0, method: 'MWL' },
            { id: 'berlin', nameAr: 'برلين', nameEn: 'Berlin', country: 'Germany', lat: 52.5200, lng: 13.4050, tz: 1, method: 'MWL' },
            { id: 'madrid', nameAr: 'مدريد', nameEn: 'Madrid', country: 'Spain', lat: 40.4168, lng: -3.7038, tz: 1, method: 'MWL' },
            { id: 'newyork', nameAr: 'نيويورك', nameEn: 'New York', country: 'USA', lat: 40.7128, lng: -74.0060, tz: -5, method: 'ISNA' },
            { id: 'toronto', nameAr: 'تورونتو', nameEn: 'Toronto', country: 'Canada', lat: 43.6532, lng: -79.3832, tz: -5, method: 'ISNA' },
            { id: 'jakarta', nameAr: 'جاكرتا', nameEn: 'Jakarta', country: 'Indonesia', lat: -6.2088, lng: 106.8456, tz: 7, method: 'MWL' },
            { id: 'kualalumpur', nameAr: 'كوالالمبور', nameEn: 'Kuala Lumpur', country: 'Malaysia', lat: 3.1390, lng: 101.6869, tz: 8, method: 'MWL' },
            { id: 'karachi', nameAr: 'كراتشي', nameEn: 'Karachi', country: 'Pakistan', lat: 24.8607, lng: 67.0011, tz: 5, method: 'Karachi' },
            { id: 'lahore', nameAr: 'لاهور', nameEn: 'Lahore', country: 'Pakistan', lat: 31.5204, lng: 74.3587, tz: 5, method: 'Karachi' },
            { id: 'dhaka', nameAr: 'دكا', nameEn: 'Dhaka', country: 'Bangladesh', lat: 23.8103, lng: 90.4125, tz: 6, method: 'Karachi' }
        ];

        this.kaaba = { lat: 21.422487, lng: 39.826206 };
    }

    // Mathematical helper functions
    degToRad(deg) { return (deg * Math.PI) / 180.0; }
    radToDeg(rad) { return (rad * 180.0) / Math.PI; }
    sinDeg(deg) { return Math.sin(this.degToRad(deg)); }
    cosDeg(deg) { return Math.cos(this.degToRad(deg)); }
    tanDeg(deg) { return Math.tan(this.degToRad(deg)); }
    asinDeg(val) { return this.radToDeg(Math.asin(val)); }
    acosDeg(val) { return this.radToDeg(Math.acos(val)); }
    atanDeg(val) { return this.radToDeg(Math.atan(val)); }
    atan2Deg(y, x) { return this.radToDeg(Math.atan2(y, x)); }

    fixAngle(angle) {
        let a = angle - 360.0 * Math.floor(angle / 360.0);
        return a < 0 ? a + 360.0 : a;
    }

    fixHour(hour) {
        let h = hour - 24.0 * Math.floor(hour / 24.0);
        return h < 0 ? h + 24.0 : h;
    }

    // Julian Date from Gregorian Date
    getJulianDate(year, month, day) {
        if (month <= 2) {
            year -= 1;
            month += 12;
        }
        let A = Math.floor(year / 100);
        let B = 2 - A + Math.floor(A / 4);
        return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5;
    }

    // Sun's declination & Equation of Time
    sunPosition(jd) {
        let D = jd - 2451545.0;
        let g = this.fixAngle(357.529 + 0.98560028 * D);
        let q = this.fixAngle(280.459 + 0.98564736 * D);
        let L = this.fixAngle(q + 1.915 * this.sinDeg(g) + 0.020 * this.sinDeg(2 * g));

        let e = 23.439 - 0.00000036 * D;
        let d = this.asinDeg(this.sinDeg(e) * this.sinDeg(L));
        let RA = this.atan2Deg(this.cosDeg(e) * this.sinDeg(L), this.cosDeg(L)) / 15.0;
        RA = this.fixHour(RA);
        let EqT = q / 15.0 - RA;

        return { declination: d, equationOfTime: EqT };
    }

    // Mid-day (Solar Noon)
    midDay(timeZone, lng, eqt) {
        return this.fixHour(12 + timeZone - lng / 15.0 - eqt);
    }

    // Sun angle time (for Fajr, Sunrise, Sunset, Isha)
    sunAngleTime(angle, midDay, declination, lat, direction = 'ccw') {
        let n = -this.sinDeg(angle) - this.sinDeg(lat) * this.sinDeg(declination);
        let d = this.cosDeg(lat) * this.cosDeg(declination);
        let val = n / d;

        if (val < -1) val = -1;
        if (val > 1) val = 1;

        let T = this.acosDeg(val) / 15.0;
        return direction === 'ccw' ? midDay - T : midDay + T;
    }

    // Asr time based on shadow factor
    asrTime(factor, midDay, declination, lat) {
        let angle = -this.atanDeg(1.0 / (factor + this.tanDeg(Math.abs(lat - declination))));
        return this.sunAngleTime(angle, midDay, declination, lat, 'cw');
    }

    /**
     * Calculate prayer times for given date and coordinates
     */
    calculatePrayerTimes(date, lat, lng, timeZone = null, methodName = null, asrSchool = null) {
        if (!date) date = new Date();
        if (timeZone === null) {
            timeZone = -date.getTimezoneOffset() / 60;
        }
        let method = this.methods[methodName || this.currentMethod] || this.methods.MWL;
        let asrFactor = (asrSchool || this.asrMethod) === 'hanafi' ? 2 : 1;

        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let day = date.getDate();

        let jd = this.getJulianDate(year, month, day);
        let sun = this.sunPosition(jd);

        let dhuhr = this.midDay(timeZone, lng, sun.equationOfTime) + (this.dhuhrMinutesOffset / 60.0);
        let sunrise = this.sunAngleTime(0.833, dhuhr, sun.declination, lat, 'ccw');
        let sunset = this.sunAngleTime(0.833, dhuhr, sun.declination, lat, 'cw');
        let fajr = this.sunAngleTime(method.fajrAngle, dhuhr, sun.declination, lat, 'ccw');
        let asr = this.asrTime(asrFactor, dhuhr, sun.declination, lat);

        let maghrib = sunset; // Solar sunset
        let isha;

        if (method.ishaInterval) {
            isha = maghrib + (method.ishaInterval / 60.0);
        } else {
            isha = this.sunAngleTime(method.ishaAngle, dhuhr, sun.declination, lat, 'cw');
        }

        return {
            fajr: this.floatToTimeObj(fajr, date),
            sunrise: this.floatToTimeObj(sunrise, date),
            dhuhr: this.floatToTimeObj(dhuhr, date),
            asr: this.floatToTimeObj(asr, date),
            maghrib: this.floatToTimeObj(maghrib, date),
            isha: this.floatToTimeObj(isha, date),
            method: method.name
        };
    }

    floatToTimeObj(decimalHours, baseDate) {
        decimalHours = this.fixHour(decimalHours);
        let hours = Math.floor(decimalHours);
        let minutes = Math.floor((decimalHours - hours) * 60);
        let seconds = Math.floor(((decimalHours - hours) * 60 - minutes) * 60);

        let dateObj = new Date(baseDate);
        dateObj.setHours(hours, minutes, seconds, 0);

        let pad = (n) => String(n).padStart(2, '0');
        let time24 = `${pad(hours)}:${pad(minutes)}`;

        let period = hours >= 12 ? 'PM' : 'AM';
        let periodAr = hours >= 12 ? 'م' : 'ص';
        let h12 = hours % 12 || 12;
        let time12 = `${pad(h12)}:${pad(minutes)} ${period}`;
        let time12Ar = `${pad(h12)}:${pad(minutes)} ${periodAr}`;

        return {
            hours,
            minutes,
            seconds,
            time24,
            time12,
            time12Ar,
            date: dateObj
        };
    }

    /**
     * Determine current and next prayer, and time remaining
     */
    getNextPrayer(times, now = new Date()) {
        const prayers = [
            { key: 'fajr', nameAr: 'الفجر', nameEn: 'Fajr', time: times.fajr.date },
            { key: 'sunrise', nameAr: 'الشروق', nameEn: 'Sunrise', time: times.sunrise.date },
            { key: 'dhuhr', nameAr: 'الظهر', nameEn: 'Dhuhr', time: times.dhuhr.date },
            { key: 'asr', nameAr: 'العصر', nameEn: 'Asr', time: times.asr.date },
            { key: 'maghrib', nameAr: 'المغرب', nameEn: 'Maghrib', time: times.maghrib.date },
            { key: 'isha', nameAr: 'العشاء', nameEn: 'Isha', time: times.isha.date }
        ];

        let current = null;
        let next = null;

        for (let i = 0; i < prayers.length; i++) {
            if (now >= prayers[i].time) {
                current = prayers[i];
            } else {
                next = prayers[i];
                break;
            }
        }

        // If after Isha, current is Isha and next is tomorrow's Fajr
        if (!next) {
            current = prayers[prayers.length - 1]; // Isha
            let tomorrowFajr = new Date(times.fajr.date);
            tomorrowFajr.setDate(tomorrowFajr.getDate() + 1);
            next = { key: 'fajr', nameAr: 'الفجر', nameEn: 'Fajr', time: tomorrowFajr, isTomorrow: true };
        }

        if (!current) {
            // Before today's Fajr, current is yesterday's Isha
            current = { key: 'isha', nameAr: 'العشاء', nameEn: 'Isha' };
            next = prayers[0]; // Fajr
        }

        let diffMs = next.time.getTime() - now.getTime();
        if (diffMs < 0) diffMs = 0;

        let diffSec = Math.floor(diffMs / 1000);
        let hours = Math.floor(diffSec / 3600);
        let minutes = Math.floor((diffSec % 3600) / 60);
        let seconds = diffSec % 60;

        let pad = (n) => String(n).padStart(2, '0');
        let countdownStr = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;

        return {
            current,
            next,
            diffMs,
            countdownStr,
            hours,
            minutes,
            seconds
        };
    }

    /**
     * Calculate Qibla bearing and distance from coordinates
     */
    calculateQibla(userLat, userLng) {
        let lat1 = this.degToRad(userLat);
        let lng1 = this.degToRad(userLng);
        let lat2 = this.degToRad(this.kaaba.lat);
        let lng2 = this.degToRad(this.kaaba.lng);

        let dLng = lng2 - lng1;

        let y = Math.sin(dLng) * Math.cos(lat2);
        let x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);

        let bearing = this.radToDeg(Math.atan2(y, x));
        bearing = (bearing + 360) % 360;

        // Calculate distance via Haversine formula
        let R = 6371; // Earth's radius in km
        let dLat = lat2 - lat1;
        let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2);
        let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        let distanceKm = Math.round(R * c);

        // Direction compass name
        const compassDirections = [
            { name: 'N', nameAr: 'شمال', min: 348.75, max: 11.25 },
            { name: 'NNE', nameAr: 'شمال شمال شرق', min: 11.25, max: 33.75 },
            { name: 'NE', nameAr: 'شمال شرق', min: 33.75, max: 56.25 },
            { name: 'ENE', nameAr: 'شرق شمال شرق', min: 56.25, max: 78.75 },
            { name: 'E', nameAr: 'شرق', min: 78.75, max: 101.25 },
            { name: 'ESE', nameAr: 'شرق جنوب شرق', min: 101.25, max: 123.75 },
            { name: 'SE', nameAr: 'جنوب شرق', min: 123.75, max: 146.25 },
            { name: 'SSE', nameAr: 'جنوب جنوب شرق', min: 146.25, max: 168.75 },
            { name: 'S', nameAr: 'جنوب', min: 168.75, max: 191.25 },
            { name: 'SSW', nameAr: 'جنوب جنوب غرب', min: 191.25, max: 213.75 },
            { name: 'SW', nameAr: 'جنوب غرب', min: 213.75, max: 236.25 },
            { name: 'WSW', nameAr: 'غرب جنوب غرب', min: 236.25, max: 258.75 },
            { name: 'W', nameAr: 'غرب', min: 258.75, max: 281.25 },
            { name: 'WNW', nameAr: 'غرب شمال غرب', min: 281.25, max: 303.75 },
            { name: 'NW', nameAr: 'شمال غرب', min: 303.75, max: 326.25 },
            { name: 'NNW', nameAr: 'شمال شمال غرب', min: 326.25, max: 348.75 }
        ];

        let compassDir = compassDirections.find(d => 
            (d.min > d.max && (bearing >= d.min || bearing < d.max)) ||
            (bearing >= d.min && bearing < d.max)
        ) || { name: 'E', nameAr: 'شرق' };

        return {
            bearing: Math.round(bearing * 10) / 10,
            distanceKm,
            directionEn: compassDir.name,
            directionAr: compassDir.nameAr
        };
    }

    /**
     * Accurate Hijri Date Calculator
     */
    getHijriDate(date = new Date(), adjustmentDays = 0) {
        let d = new Date(date);
        d.setDate(d.getDate() + adjustmentDays);

        let day = d.getDate();
        let month = d.getMonth();
        let year = d.getFullYear();

        let m = month + 1;
        let y = year;
        if (m < 3) {
            y -= 1;
            m += 12;
        }

        let a = Math.floor(y / 100.);
        let b = 2 - a + Math.floor(a / 4.);
        if (y < 1583) b = 0;
        if (y === 1582) {
            if (m > 10) b = -10;
            if (m === 10) {
                b = 0;
                if (day > 4) b = -10;
            }
        }

        let jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524;
        b = 0;
        if (jd > 2299160) {
            a = Math.floor((jd - 1867216.25) / 36524.25);
            b = 1 + a - Math.floor(a / 4.);
        }
        let bb = jd + b + 1524;
        let cc = Math.floor((bb - 122.1) / 365.25);
        let dd = Math.floor(365.25 * cc);
        let ee = Math.floor((bb - dd) / 30.6001);

        let dayG = bb - dd - Math.floor(30.6001 * ee);
        let monthG = ee - 1;
        if (ee > 13) {
            cc += 1;
            monthG = ee - 13;
        }
        let yearG = cc - 4716;

        let ijd = jd - 1948440 + 10632;
        let n = Math.floor((ijd - 1) / 10631);
        ijd = ijd - 10631 * n + 354;
        let j = (Math.floor((10985 - ijd) / 5316)) * (Math.floor((50 * ijd) / 17719)) + (Math.floor(ijd / 5670)) * (Math.floor((43 * ijd) / 15238));
        ijd = ijd - (Math.floor((30 - j) / 15)) * (Math.floor((17719 * j) / 50)) - (Math.floor(j / 16)) * (Math.floor((15238 * j) / 43)) + 29;
        let hijriMonth = Math.floor((24 * ijd) / 709);
        let hijriDay = ijd - Math.floor((709 * hijriMonth) / 24);
        let hijriYear = 30 * n + j - 30;

        const hijriMonthsAr = [
            'محرّم', 'صفر', 'ربيع الأول', 'ربيع الآخر',
            'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان',
            'رمضان', 'شوّال', 'ذو القعدة', 'ذو الحجة'
        ];

        const hijriMonthsEn = [
            'Muharram', 'Safar', 'Rabi al-Awwal', 'Rabi al-Thani',
            'Jumada al-Ula', 'Jumada al-Akhirah', 'Rajab', 'Shaban',
            'Ramadan', 'Shawwal', 'Dhu al-Qadah', 'Dhu al-Hijjah'
        ];

        let mIdx = Math.max(0, Math.min(11, hijriMonth - 1));

        return {
            day: hijriDay,
            month: hijriMonth,
            year: hijriYear,
            monthNameAr: hijriMonthsAr[mIdx],
            monthNameEn: hijriMonthsEn[mIdx],
            formattedAr: `${hijriDay} ${hijriMonthsAr[mIdx]} ${hijriYear} هـ`,
            formattedEn: `${hijriDay} ${hijriMonthsEn[mIdx]} ${hijriYear} AH`
        };
    }
}

// Export singleton instance
window.PrayerTimesCalc = new PrayerTimesCalculator();

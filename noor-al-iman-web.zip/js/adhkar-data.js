/**
 * Noor Al-Iman - Adhkar Database
 * Authentic Morning, Evening, and Before Sleep Adhkar with Arabic, Transliteration, English Translation & Virtues.
 */

const ADHKAR_CATEGORIES = [
    { id: 'morning', nameAr: 'أذكار الصباح', nameEn: 'Morning Adhkar', icon: 'sunrise', time: 'بعد صلاة الفجر حتى طلوع الشمس' },
    { id: 'evening', nameAr: 'أذكار المساء', nameEn: 'Evening Adhkar', icon: 'sunset', time: 'بعد صلاة العصر حتى غروب الشمس' },
    { id: 'sleep', nameAr: 'أذكار النوم', nameEn: 'Before Sleeping', icon: 'moon', time: 'عند إرادة النوم على طهارة' },
    { id: 'tasbeeh', nameAr: 'التسبيح والاستغفار', nameEn: 'Daily Tasbeeh', icon: 'disc', time: 'في كل وقت وحين' }
];

const ADHKAR_DATA = [
    // ==========================================
    // MORNING ADHKAR (أذكار الصباح)
    // ==========================================
    {
        id: 'm1',
        category: 'morning',
        arabic: 'أَعُوذُ بِاللهِ مِنَ الشَّيْطَانِ الرَّجِيمِ: ﴿اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ﴾',
        transliteration: "Allahu la ilaha illa Huwa, Al-Hayyul-Qayyum. La ta'khudhuhu sinatun wa la nawm...",
        translation: "Allah! There is no deity except Him, the Ever-Living, the Sustainer of all existence. Neither drowsiness overtakes Him nor sleep...",
        repeat: 1,
        benefit: 'من قرأها حين يصبح أُجير من الجن حتى يمسي.',
        benefitEn: 'Whoever recites this in the morning will be protected from jinn until the evening.',
        reference: 'سورة البقرة: 255 | رواه الحاكم وصححه الألباني'
    },
    {
        id: 'm2',
        category: 'morning',
        arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ ﴿قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ﴾\n\nبِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ ﴿قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ﴾\n\nبِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ ﴿قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ﴾',
        transliteration: "Qul Huwa Allahu Ahad... Qul A'udhu bi Rabbil-Falaq... Qul A'udhu bi Rabbin-Nas...",
        translation: "Surah Al-Ikhlas, Surah Al-Falaq, Surah An-Nas.",
        repeat: 3,
        benefit: 'تكفيك من كل شيء.',
        benefitEn: 'Whoever recites them three times in the morning and evening, they will suffice him against everything.',
        reference: 'رواه أبو داود والترمذي وصححه الألباني'
    },
    {
        id: 'm3',
        category: 'morning',
        arabic: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ، وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ.',
        transliteration: "Asbahna wa asbahal-mulku lillah, wal-hamdu lillah, la ilaha illallahu wahdahu la sharika lah...",
        translation: "We have entered the morning and the dominion belongs to Allah, and all praise is due to Allah. None has the right to be worshipped except Allah alone, without partner...",
        repeat: 1,
        benefit: 'من أذكار الصباح العظيمة للتبرؤ من الحول والقوة وسؤال خير اليوم.',
        benefitEn: 'Supplication for protection, seeking goodness of the day, and refuge from laziness and the grave.',
        reference: 'صحيح مسلم (2723)'
    },
    {
        id: 'm4',
        category: 'morning',
        arabic: 'اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوبَ إِلاَّ أَنْتَ.',
        transliteration: "Allahumma Anta Rabbi la ilaha illa Anta, khalaqtani wa ana 'abduka...",
        translation: "O Allah, You are my Lord; there is none worthy of worship except You. You created me and I am Your servant, and I abide by Your covenant and promise as much as I am able...",
        repeat: 1,
        benefit: 'سيد الاستغفار: من قالها موقناً بها حين يصبح فمات من يومه دخل الجنة.',
        benefitEn: 'The Master Supplication for Forgiveness: Whoever says it with certainty in the morning and dies that day will enter Paradise.',
        reference: 'صحيح البخاري (6306)'
    },
    {
        id: 'm5',
        category: 'morning',
        arabic: 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ.',
        transliteration: "Allahumma bika asbahna, wa bika amsayna, wa bika nahya, wa bika namutu wa ilaykan-nushur.",
        translation: "O Allah, by Your leave we have reached the morning and by Your leave we reach the evening, by Your leave we live and die and unto You is our resurrection.",
        repeat: 1,
        benefit: 'اعتراف بنعمة الحياة وتفويض الأمر لله في مطلع اليوم.',
        benefitEn: 'Affirming that our life, death, and return are completely in Allah\'s hands.',
        reference: 'رواه الترمذي وصححه الألباني'
    },
    {
        id: 'm6',
        category: 'morning',
        arabic: 'اللَّهُمَّ إِنِّي أَصْبَحْتُ أُشْهِدُكَ، وَأُشْهِدُ حَمَلَةَ عَرْشِكَ، وَمَلاَئِكَتَكَ، وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لاَ إِلَهَ إِلاَّ أَنْتَ وَحْدَكَ لاَ شَرِيكَ لَكَ، وَأَنَّ مُحَمَّداً عَبْدُكَ وَرَسُولُكَ.',
        transliteration: "Allahumma inni asbahtu ushhiduka wa ushhidu hamalata 'arshika wa mala'ikataka...",
        translation: "O Allah, verily I have entered the morning and I call You to witness, along with the bearers of Your Throne, Your angels, and all Your creation, that You are Allah, none has the right to be worshipped except You...",
        repeat: 4,
        benefit: 'من قالها حين يصبح أو يمسي أربع مرات أعتقه الله من النار.',
        benefitEn: 'Whoever recites this four times in the morning or evening, Allah will free him from the Hellfire.',
        reference: 'رواه أبو داود (5069)'
    },
    {
        id: 'm7',
        category: 'morning',
        arabic: 'اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لاَ إِلَهَ إِلاَّ أَنْتَ. اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ، وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لاَ إِلَهَ إِلاَّ أَنْتَ.',
        transliteration: "Allahumma 'afini fi badani, Allahumma 'afini fi sam'i, Allahumma 'afini fi basari, la ilaha illa Anta...",
        translation: "O Allah, grant my body health. O Allah, grant my hearing health. O Allah, grant my sight health. None has the right to be worshipped except You...",
        repeat: 3,
        benefit: 'سؤال الله دوام الصحة والعافية والسلامة من الفقر وعذاب القبر.',
        benefitEn: 'Supplication for continuous health, hearing, sight, and protection from disbelief and poverty.',
        reference: 'رواه أبو داود وصححه الألباني'
    },
    {
        id: 'm8',
        category: 'morning',
        arabic: 'حَسْبِيَ اللَّهُ لاَ إِلَهَ إِلاَّ هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ.',
        transliteration: "Hasbiyallahu la ilaha illa Huwa 'alayhi tawakkaltu wa Huwa Rabbul-'Arshil-'Azim.",
        translation: "Allah is sufficient for me. There is none worthy of worship except Him. In Him I have put my trust, and He is the Lord of the Mighty Throne.",
        repeat: 7,
        benefit: 'من قالها سبع مرات كفاه الله ما أهمه من أمر الدنيا والآخرة.',
        benefitEn: 'Whoever says it seven times in the morning and evening, Allah will suffice him in everything that concerns him in this life and the Hereafter.',
        reference: 'رواه أبو داود وصححه ابن باز'
    },
    {
        id: 'm9',
        category: 'morning',
        arabic: 'بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.',
        transliteration: "Bismillahilladhi la yadurru ma'asmihi shay'un fil-ardi wa la fis-sama'i wa Huwas-Sami'ul-'Alim.",
        translation: "In the name of Allah, with whose name nothing can cause harm in the earth or in the heavens, and He is the All-Hearing, the All-Knowing.",
        repeat: 3,
        benefit: 'من قالها ثلاثاً لم يضره شيء حتى يمسي أو يصبح.',
        benefitEn: 'Whoever recites it three times, nothing will harm him until evening or morning.',
        reference: 'رواه أبو داود والترمذي وصححه الألباني'
    },
    {
        id: 'm10',
        category: 'morning',
        arabic: 'رَضِيتُ بِاللَّهِ رَبّاً، وَبِالإِسْلاَمِ دِيناً، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيّاً.',
        transliteration: "Raditu billahi Rabban, wa bil-Islami dinan, wa bi Muhammadin sallallahu 'alayhi wa sallama Nabiyya.",
        translation: "I am pleased with Allah as my Lord, with Islam as my religion, and with Muhammad (peace and blessings of Allah be upon him) as my Prophet.",
        repeat: 3,
        benefit: 'كان حقاً على الله أن يرضيه يوم القيامة.',
        benefitEn: 'Whoever says it three times, Allah will surely make him pleased on the Day of Resurrection.',
        reference: 'رواه أحمد والترمذي وحسنه الألباني'
    },
    {
        id: 'm11',
        category: 'morning',
        arabic: 'يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلاَ تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.',
        transliteration: "Ya Hayyu Ya Qayyumu birahmatika astagheeth, aslih li sha'ni kullahu wa la takilni ila nafsi tarfata 'ayn.",
        translation: "O Ever-Living, O Self-Subsisting, by Your mercy I seek assistance. Rectify for me all of my affairs and do not leave me to myself even for the blink of an eye.",
        repeat: 1,
        benefit: 'دعاء جامع لصلاح الشأن كله وطلب العون الإلهي.',
        benefitEn: 'A comprehensive supplication seeking Allah\'s complete rectification and mercy.',
        reference: 'رواه الحاكم وصححه الألباني'
    },
    {
        id: 'm12',
        category: 'morning',
        arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ.',
        transliteration: "Subhanallahi wa bihamdihi: 'adada khalqihi, wa rida nafsihi, wa zinata 'arshihi, wa midada kalimatih.",
        translation: "Glory is to Allah and praise is to Him, by the number of His creation and His pleasure, and by the weight of His throne, and the ink of His words.",
        repeat: 3,
        benefit: 'تعدل ساعات طويلة من الذكر والتسبيح.',
        benefitEn: 'Outweighs hours of prolonged dhikr in reward and magnitude.',
        reference: 'صحيح مسلم (2726)'
    },
    {
        id: 'm13',
        category: 'morning',
        arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.',
        transliteration: "Subhanallahi wa bihamdih.",
        translation: "Glory be to Allah and His is the praise.",
        repeat: 100,
        benefit: 'حُطت خطاياه وإن كانت مثل زبد البحر، ولم يأتِ أحد يوم القيامة بأفضل مما جاء به إلا أحد قال مثل ما قال أو زاد.',
        benefitEn: 'Sins are forgiven even if they were like the foam of the sea, and no one will bring better than it on the Day of Judgment.',
        reference: 'صحيح مسلم (2691)'
    },
    {
        id: 'm14',
        category: 'morning',
        arabic: 'لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.',
        transliteration: "La ilaha illallahu wahdahu la sharika lah, lahul-mulku wa lahul-hamdu, wa Huwa 'ala kulli shay'in qadir.",
        translation: "None has the right to be worshipped except Allah alone, without partner. His is the sovereignty and His is the praise and He is over all things omnipotent.",
        repeat: 10,
        benefit: 'كانت له عدل عشر رقاب، وكُتبت له مائة حسنة، ومُحيت عنه مائة سيئة، وكانت له حرزاً من الشيطان.',
        benefitEn: 'Equivalent to freeing slaves, earns 100 good deeds, erases 100 sins, and protects from Shaytan.',
        reference: 'صحيح البخاري ومسلم'
    },
    {
        id: 'm15',
        category: 'morning',
        arabic: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.',
        transliteration: "Allahumma salli wa sallim 'ala Nabiyyina Muhammad.",
        translation: "O Allah, send prayers and peace upon our Prophet Muhammad.",
        repeat: 10,
        benefit: 'من صلى عليّ حين يصبح عشراً وحين يمسي عشراً أدركته شفاعتي يوم القيامة.',
        benefitEn: 'Whoever sends blessings upon me ten times in the morning and ten in the evening will attain my intercession on the Day of Resurrection.',
        reference: 'رواه الطبراني وحسنه الألباني'
    },

    // ==========================================
    // EVENING ADHKAR (أذكار المساء)
    // ==========================================
    {
        id: 'e1',
        category: 'evening',
        arabic: 'أَعُوذُ بِاللهِ مِنَ الشَّيْطَانِ الرَّجِيمِ: ﴿اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ﴾',
        transliteration: "Allahu la ilaha illa Huwa, Al-Hayyul-Qayyum...",
        translation: "Ayat Al-Kursi (The Verse of the Throne).",
        repeat: 1,
        benefit: 'من قرأها حين يمسي أُجير من الجن حتى يصبح.',
        benefitEn: 'Whoever recites this in the evening will be protected from jinn until the morning.',
        reference: 'سورة البقرة: 255 | رواه الحاكم وصححه الألباني'
    },
    {
        id: 'e2',
        category: 'evening',
        arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ ﴿قُلْ هُوَ اللَّهُ أَحَدٌ...﴾، ﴿قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ...﴾، ﴿قُلْ أَعُوذُ بِرَبِّ النَّاسِ...﴾',
        transliteration: "Surah Al-Ikhlas, Al-Falaq, An-Nas.",
        translation: "Surah Al-Ikhlas, Surah Al-Falaq, Surah An-Nas (Recited 3 times each).",
        repeat: 3,
        benefit: 'تكفيك من كل شيء.',
        benefitEn: 'Reciting them three times suffices against all harm.',
        reference: 'رواه أبو داود والترمذي'
    },
    {
        id: 'e3',
        category: 'evening',
        arabic: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ، وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ.',
        transliteration: "Amsayna wa amsal-mulku lillah, wal-hamdu lillah, la ilaha illallahu wahdahu la sharika lah...",
        translation: "We have reached the evening and the dominion belongs to Allah, and all praise is for Allah...",
        repeat: 1,
        benefit: 'سؤال خير الليلة والتعوذ من شرها وعذاب القبر والنار.',
        benefitEn: 'Supplication for entering the evening safely and seeking Allah\'s protection.',
        reference: 'صحيح مسلم (2723)'
    },
    {
        id: 'e4',
        category: 'evening',
        arabic: 'اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوبَ إِلاَّ أَنْتَ.',
        transliteration: "Allahumma Anta Rabbi la ilaha illa Anta, khalaqtani wa ana 'abduka...",
        translation: "Sayyid al-Istighfar (The Master Supplication for Forgiveness).",
        repeat: 1,
        benefit: 'من قالها موقناً بها حين يمسي فمات من ليلته دخل الجنة.',
        benefitEn: 'Whoever recites it in the evening with firm faith and dies that night will enter Paradise.',
        reference: 'صحيح البخاري (6306)'
    },
    {
        id: 'e5',
        category: 'evening',
        arabic: 'اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ.',
        transliteration: "Allahumma bika amsayna, wa bika asbahna, wa bika nahya, wa bika namutu wa ilaykal-masir.",
        translation: "O Allah, by Your leave we have reached the evening, by Your leave we reach the morning, by You we live, by You we die, and unto You is our return.",
        repeat: 1,
        benefit: 'ذكر الإنابة والاعتراف بالخضوع لله ومصير العباد إليه.',
        benefitEn: 'Affirming that our return is to Allah alone.',
        reference: 'رواه الترمذي وصححه الألباني'
    },
    {
        id: 'e6',
        category: 'evening',
        arabic: 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.',
        transliteration: "A'udhu bi kalimatillahit-tammati min sharri ma khalaq.",
        translation: "I seek refuge in the perfect words of Allah from the evil of what He has created.",
        repeat: 3,
        benefit: 'من قالها حين يمسي ثلاث مرات لم تضره حُمَة (لدغة عقرب أو حية) في تلك الليلة.',
        benefitEn: 'Whoever says it three times in the evening will not be harmed by poisonous stings or evil that night.',
        reference: 'صحيح مسلم (2709)'
    },
    {
        id: 'e7',
        category: 'evening',
        arabic: 'بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.',
        transliteration: "Bismillahilladhi la yadurru ma'asmihi shay'un fil-ardi wa la fis-sama'i wa Huwas-Sami'ul-'Alim.",
        translation: "In the name of Allah, with whose name nothing can cause harm in the earth or in the heavens...",
        repeat: 3,
        benefit: 'حصن من كل ضرر ومكروه وفجأة بلاء.',
        benefitEn: 'Protection from all harm, calamities, and sickness.',
        reference: 'رواه أبو داود والترمذي'
    },
    {
        id: 'e8',
        category: 'evening',
        arabic: 'رَضِيتُ بِاللَّهِ رَبّاً، وَبِالإِسْلاَمِ دِيناً، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيّاً.',
        transliteration: "Raditu billahi Rabban, wa bil-Islami dinan, wa bi Muhammadin sallallahu 'alayhi wa sallama Nabiyya.",
        translation: "I am pleased with Allah as my Lord, Islam as my religion, and Muhammad (pbuh) as my Prophet.",
        repeat: 3,
        benefit: 'كان حقاً على الله أن يرضيه يوم القيامة.',
        benefitEn: 'Guarantees Allah\'s pleasure on the Day of Resurrection.',
        reference: 'رواه الترمذي وحسنه'
    },
    {
        id: 'e9',
        category: 'evening',
        arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي، اللَّهُمَّ اسْتُرْ عَوْرَاتِي، وَآمِنْ رَوْعَاتِي، اللَّهُمَّ احْفَظْنِي مِنْ بَيْنِ يَدَيَّ، وَمِنْ خَلْفِي، وَعَنْ يَمِينِي، وَعَنْ شِمَالِي، وَمِنْ فَوْقِي، وَأَعُوذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِي.',
        transliteration: "Allahumma inni as'alukal-'afwa wal-'afiyata fid-dunya wal-akhirah...",
        translation: "O Allah, I ask You for pardon and well-being in this world and the Hereafter. O Allah, I ask You for well-being in my religion, worldly affairs, family, and wealth...",
        repeat: 1,
        benefit: 'دعاء الحفظ الشامل من الجهات الست (لم يكن النبي ﷺ يدعه حين يصبح وحين يمسي).',
        benefitEn: 'Comprehensive protection from all sides; the Prophet (pbuh) never omitted this supplication.',
        reference: 'رواه أبو داود وصححه الحاكم'
    },
    {
        id: 'e10',
        category: 'evening',
        arabic: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.',
        transliteration: "Allahumma salli wa sallim 'ala Nabiyyina Muhammad.",
        translation: "O Allah, send prayers and peace upon our Prophet Muhammad.",
        repeat: 10,
        benefit: 'من صلى عليّ حين يصبح عشراً وحين يمسي عشراً أدركته شفاعتي.',
        benefitEn: 'Attaining the Prophet\'s intercession on the Day of Judgment.',
        reference: 'رواه الطبراني'
    },

    // ==========================================
    // BEFORE SLEEPING ADHKAR (أذكار النوم)
    // ==========================================
    {
        id: 's1',
        category: 'sleep',
        arabic: 'يَجْمَعُ كَفَّيْهِ ثُمَّ يَنْفُثُ فِيهِمَا فَيَقْرَأُ: ﴿قُلْ هُوَ اللَّهُ أَحَدٌ﴾، وَ﴿قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ﴾، وَ﴿قُلْ أَعُوذُ بِرَبِّ النَّاسِ﴾، ثُمَّ يَمْسَحُ بِهِمَا مَا اسْتَطَاعَ مِنْ جَسَدِهِ، يَبْدَأُ بِهِمَا عَلَى رَأْسِهِ وَوَجْهِهِ وَمَا أَقْبَلَ مِنْ جَسَدِهِ.',
        transliteration: "Cup hands together, blow gently into them, recite Surah Al-Ikhlas, Al-Falaq, and An-Nas, and wipe as much of the body as possible...",
        translation: "Cup hands, blow into them, recite the three Quls, and wipe over the head, face, and front of the body (repeat 3 times).",
        repeat: 3,
        benefit: 'سنة نبوية شريفة للحفظ والوقاية من الشياطين والوسواس طوال الليل.',
        benefitEn: 'Prophetic sunnah for protection against nightmares and evil spirits throughout the night.',
        reference: 'صحيح البخاري (5017)'
    },
    {
        id: 's2',
        category: 'sleep',
        arabic: 'أَعُوذُ بِاللهِ مِنَ الشَّيْطَانِ الرَّجِيمِ: ﴿اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ...﴾ (آية الكرسي كاملة).',
        transliteration: "Recitation of Ayat Al-Kursi before sleeping.",
        translation: "The Verse of the Throne (Surah Al-Baqarah: 255).",
        repeat: 1,
        benefit: 'لن يزال عليك من الله حافظ، ولا يقربك شيطان حتى تصبح.',
        benefitEn: 'A guardian from Allah will remain with you, and no devil will come near you until morning.',
        reference: 'صحيح البخاري (2311)'
    },
    {
        id: 's3',
        category: 'sleep',
        arabic: '﴿آمَنَ الرَّسُولُ بِمَا أُنزِلَ إِلَيْهِ مِن رَّبِّهِ وَالْمُؤْمِنُونَ ۚ كُلٌّ آمَنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ لَا نُفَرِّقُ بَيْنَ أَحَدٍ مِّن رُّسُلِهِ ۚ وَقَالُوا سَمِعْنَا وَأَطَعْنَا ۖ غُفْرَانَكَ رَبَّنَا وَإِلَيْكَ الْمَصِيرُ ۝ لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا ۚ لَهَا مَا كَسَبَتْ وَعَلَيْهَا مَا اكْتَسَبَتْ ۗ رَبَّنَا لَا تُؤَاخِذْنَا إِن نَّسِينَا أَوْ أَخْطَأْنَا ۚ رَبَّنَا وَلَا تَحْمِلْ عَلَيْنَا إِصْرًا كَمَا حَمَلْتَهُ عَلَى الَّذِينَ مِن قَبْلِنَا ۚ رَبَّنَا وَلَا تُحَمِّلْنَا مَا لَا طَاقَةَ لَنَا بِهِ ۖ وَاعْفُ عَنَّا وَاغْفِرْ لَنَا وَارْحَمْنَا ۚ أَنتَ مَوْلَانَا فَانصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ﴾',
        transliteration: "Amanar-Rasulu bima unzila ilayhi mir-Rabbihi wal-mu'minun...",
        translation: "The Messenger has believed in what was revealed to him from his Lord, and [so have] the believers... (Last two verses of Surah Al-Baqarah: 285-286).",
        repeat: 1,
        benefit: 'من قرأ بالآيتين من آخر سورة البقرة في ليلة كفتاه (من كل سوء ومكروه).',
        benefitEn: 'Whoever recites the last two verses of Surah Al-Baqarah at night, they will suffice him against all harm.',
        reference: 'صحيح البخاري ومسلم'
    },
    {
        id: 's4',
        category: 'sleep',
        arabic: 'بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.',
        transliteration: "Bismika Rabbi wada'tu janbi, wa bika arfa'uh, fa in amsakta nafsi farhamha, wa in arsaltaha fahfazha bima tahfazu bihi 'ibadakas-salihin.",
        translation: "In Your name, my Lord, I lay down my side and in Your name I raise it. If You take my soul, have mercy upon it, and if You return it, protect it as You protect Your righteous slaves.",
        repeat: 1,
        benefit: 'تسليم الروح لله عند النوم وسؤال الحفظ والرحمة.',
        benefitEn: 'Entrusting one\'s soul into Allah\'s safe custody while sleeping.',
        reference: 'صحيح البخاري (6320) ومسلم'
    },
    {
        id: 's5',
        category: 'sleep',
        arabic: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.',
        transliteration: "Allahumma qini 'adhabaka yawma tab'athu 'ibadak.",
        translation: "O Allah, protect me from Your punishment on the Day You resurrect Your slaves.",
        repeat: 3,
        benefit: 'كان النبي ﷺ إذا أراد أن يرقد وضع يده اليمنى تحت خده ثم قال هذا الدعاء ثلاثاً.',
        benefitEn: 'Recited with the right hand placed under the right cheek, seeking salvation from punishment.',
        reference: 'رواه أبو داود والترمذي وصححه الألباني'
    },
    {
        id: 's6',
        category: 'sleep',
        arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.',
        transliteration: "Bismikallahumma amutu wa ahya.",
        translation: "In Your name, O Allah, I die and I live.",
        repeat: 1,
        benefit: 'من أجمع الأدعية النبوية عند المنام.',
        benefitEn: 'Direct, beautiful prophetic sunnah upon sleeping.',
        reference: 'صحيح البخاري (6324)'
    },
    {
        id: 's7',
        category: 'sleep',
        arabic: 'تَسْبِيحُ فَاطِمَةَ رَضِيَ اللَّهُ عَنْهَا: سُبْحَانَ اللَّهِ (33 مَرَّةً)، وَالْحَمْدُ لِلَّهِ (33 مَرَّةً)، وَاللَّهُ أَكْبَرُ (34 مَرَّةً).',
        transliteration: "SubhanAllah (33x), Alhamdulillah (33x), Allahu Akbar (34x).",
        translation: "Glory be to Allah (33x), Praise be to Allah (33x), Allah is the Greatest (34x).",
        repeat: 100,
        benefit: 'أوصى بها النبي ﷺ ابنته فاطمة وعلياً رضي الله عنهما، وهي خير للعبد من خادم وتعطي قوة في البدن والروح.',
        benefitEn: 'Better than a servant, providing inner spiritual and bodily strength throughout the day.',
        reference: 'صحيح البخاري (3705) ومسلم'
    },
    {
        id: 's8',
        category: 'sleep',
        arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا، وَكَفَانَا، وَآوَانَا، فَكَمْ مِمَّنْ لاَ كَافِيَ لَهُ وَلاَ مُؤْوِيَ.',
        transliteration: "Alhamdu lillahilladhi at'amana wa saqana, wa kafana, wa awana, fakam mimman la kafiya lahu wa la mu'wi.",
        translation: "Praise is to Allah Who has provided us with food and with drink, satisfied us and gave us shelter; for how many are there who have no protector and no shelter.",
        repeat: 1,
        benefit: 'شكر نعم الله المتتالية من المأوى والرزق والأمان.',
        benefitEn: 'Gratitude for shelter, nourishment, safety, and sufficiency before going to sleep.',
        reference: 'صحيح مسلم (2715)'
    },
    {
        id: 's9',
        category: 'sleep',
        arabic: 'اللَّهُمَّ أَسْلَمْتُ نَفْسِي إِلَيْكَ، وَفَوَّضْتُ أَمْرِي إِلَيْكَ، وَوَجَّهْتُ وَجْهِي إِلَيْكَ، وَأَلْجَأْتُ ظَهْرِي إِلَيْكَ، رَغْبَةً وَرَهْبَةً إِلَيْكَ، لاَ مَلْجَأَ وَلاَ مَنْجَا مِنْكَ إِلاَّ إِلَيْكَ، آمَنْتُ بِكِتَابِكَ الَّذِي أَنْزَلْتَ، وَبِنَبِيِّكَ الَّذِي أَرْسَلْتَ.',
        transliteration: "Allahumma aslamtu nafsi ilayk, wa fawwadtu amri ilayk, wa wajjahtu wajhi ilayk, wa alja'tu zahri ilayk...",
        translation: "O Allah, I surrender my soul to You, entrust my affair to You, turn my face towards You, and rely upon You, out of hope and fear of You...",
        repeat: 1,
        benefit: 'قال النبي ﷺ: «إذا أخذت مضجعك فتوضأ وضوءك للصلاة ثم قل هذا.. فإن مت من ليلتك مت على الفطرة».',
        benefitEn: 'The Prophet (pbuh) said: If you die that night after saying this, you die upon the natural state of Islam (Fitrah).',
        reference: 'صحيح البخاري (6311) ومسلم'
    }
];

// Tasbeeh phrases presets
const TASBEEH_PRESETS = [
    { id: 'subhanallah', textAr: 'سُبْحَانَ اللَّهِ', textEn: 'SubhanAllah', target: 33, meaning: 'Glory be to Allah' },
    { id: 'alhamdulillah', textAr: 'الْحَمْدُ لِلَّهِ', textEn: 'Alhamdulillah', target: 33, meaning: 'Praise be to Allah' },
    { id: 'allahuakbar', textAr: 'اللَّهُ أَكْبَرُ', textEn: 'Allahu Akbar', target: 34, meaning: 'Allah is the Greatest' },
    { id: 'astaghfirullah', textAr: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ', textEn: 'Astaghfirullah', target: 100, meaning: 'I seek forgiveness from Allah' },
    { id: 'tahlil', textAr: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ', textEn: 'La Ilaha Illallah', target: 100, meaning: 'None has the right to be worshipped except Allah alone' },
    { id: 'salawat', textAr: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ', textEn: 'Salawat on Prophet', target: 10, meaning: 'O Allah send blessings upon Muhammad' },
    { id: 'hawqala', textAr: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', textEn: 'La Hawla wa la Quwwata illa billah', target: 100, meaning: 'There is no power nor might except with Allah' },
    { id: 'subhan_wabihamdihi', textAr: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ', textEn: 'SubhanAllahi wa biHamdihi SubhanAllahil-Azim', target: 100, meaning: 'Glory be to Allah and His praise, Glory be to Allah the Tremendous' }
];

window.ADHKAR_DATA = ADHKAR_DATA;
window.ADHKAR_CATEGORIES = ADHKAR_CATEGORIES;
window.TASBEEH_PRESETS = TASBEEH_PRESETS;

/**
 * Noor Al-Iman - Quran Engine & Database
 * Metadata for all 114 Surahs, 30 Ajzaa, offline fallback texts, and audio recitations API.
 */

const QURAN_SURAHS = [
    { number: 1, nameAr: 'الفَاتِحَة', nameEn: 'Al-Fatihah', meaning: 'The Opening', ayahs: 7, type: 'Meccan', page: 1 },
    { number: 2, nameAr: 'البَقَرَة', nameEn: 'Al-Baqarah', meaning: 'The Cow', ayahs: 286, type: 'Medinan', page: 2 },
    { number: 3, nameAr: 'آل عِمْرَان', nameEn: 'Ali \'Imran', meaning: 'Family of Imran', ayahs: 200, type: 'Medinan', page: 50 },
    { number: 4, nameAr: 'النِّسَاء', nameEn: 'An-Nisa', meaning: 'The Women', ayahs: 176, type: 'Medinan', page: 77 },
    { number: 5, nameAr: 'المَائِدَة', nameEn: 'Al-Ma\'idah', meaning: 'The Table Spread', ayahs: 120, type: 'Medinan', page: 106 },
    { number: 6, nameAr: 'الأَنْعَام', nameEn: 'Al-An\'am', meaning: 'The Cattle', ayahs: 165, type: 'Meccan', page: 128 },
    { number: 7, nameAr: 'الأَعْرَاف', nameEn: 'Al-A\'raf', meaning: 'The Heights', ayahs: 206, type: 'Meccan', page: 151 },
    { number: 8, nameAr: 'الأَنْفَال', nameEn: 'Al-Anfal', meaning: 'The Spoils of War', ayahs: 75, type: 'Medinan', page: 177 },
    { number: 9, nameAr: 'التَّوْبَة', nameEn: 'At-Tawbah', meaning: 'The Repentance', ayahs: 129, type: 'Medinan', page: 187 },
    { number: 10, nameAr: 'يُونُس', nameEn: 'Yunus', meaning: 'Jonah', ayahs: 109, type: 'Meccan', page: 208 },
    { number: 11, nameAr: 'هُود', nameEn: 'Hud', meaning: 'Hud', ayahs: 123, type: 'Meccan', page: 221 },
    { number: 12, nameAr: 'يُوسُف', nameEn: 'Yusuf', meaning: 'Joseph', ayahs: 111, type: 'Meccan', page: 235 },
    { number: 13, nameAr: 'الرَّعْد', nameEn: 'Ar-Ra\'d', meaning: 'The Thunder', ayahs: 43, type: 'Medinan', page: 249 },
    { number: 14, nameAr: 'إِبْرَاهِيم', nameEn: 'Ibrahim', meaning: 'Abraham', ayahs: 52, type: 'Meccan', page: 255 },
    { number: 15, nameAr: 'الحِجْر', nameEn: 'Al-Hijr', meaning: 'The Rocky Tract', ayahs: 99, type: 'Meccan', page: 262 },
    { number: 16, nameAr: 'النَّحْل', nameEn: 'An-Nahl', meaning: 'The Bee', ayahs: 128, type: 'Meccan', page: 267 },
    { number: 17, nameAr: 'الإِسْرَاء', nameEn: 'Al-Isra', meaning: 'The Night Journey', ayahs: 111, type: 'Meccan', page: 282 },
    { number: 18, nameAr: 'الكَهْف', nameEn: 'Al-Kahf', meaning: 'The Cave', ayahs: 110, type: 'Meccan', page: 293 },
    { number: 19, nameAr: 'مَرْيَم', nameEn: 'Maryam', meaning: 'Mary', ayahs: 98, type: 'Meccan', page: 305 },
    { number: 20, nameAr: 'طه', nameEn: 'Ta-Ha', meaning: 'Ta-Ha', ayahs: 135, type: 'Meccan', page: 312 },
    { number: 21, nameAr: 'الأَنْبِيَاء', nameEn: 'Al-Anbiya', meaning: 'The Prophets', ayahs: 112, type: 'Meccan', page: 322 },
    { number: 22, nameAr: 'الحَجّ', nameEn: 'Al-Hajj', meaning: 'The Pilgrimage', ayahs: 78, type: 'Medinan', page: 332 },
    { number: 23, nameAr: 'المُؤْمِنُون', nameEn: 'Al-Mu\'minun', meaning: 'The Believers', ayahs: 118, type: 'Meccan', page: 342 },
    { number: 24, nameAr: 'النُّور', nameEn: 'An-Nur', meaning: 'The Light', ayahs: 64, type: 'Medinan', page: 350 },
    { number: 25, nameAr: 'الفُرْقَان', nameEn: 'Al-Furqan', meaning: 'The Criterion', ayahs: 77, type: 'Meccan', page: 359 },
    { number: 26, nameAr: 'الشُّعَرَاء', nameEn: 'Ash-Shu\'ara', meaning: 'The Poets', ayahs: 227, type: 'Meccan', page: 367 },
    { number: 27, nameAr: 'النَّمْل', nameEn: 'An-Naml', meaning: 'The Ant', ayahs: 93, type: 'Meccan', page: 377 },
    { number: 28, nameAr: 'القَصَص', nameEn: 'Al-Qasas', meaning: 'The Stories', ayahs: 88, type: 'Meccan', page: 385 },
    { number: 29, nameAr: 'العَنْكَبُوت', nameEn: 'Al-\'Ankabut', meaning: 'The Spider', ayahs: 69, type: 'Meccan', page: 396 },
    { number: 30, nameAr: 'الرُّوم', nameEn: 'Ar-Rum', meaning: 'The Romans', ayahs: 60, type: 'Meccan', page: 404 },
    { number: 31, nameAr: 'لُقْمَان', nameEn: 'Luqman', meaning: 'Luqman', ayahs: 34, type: 'Meccan', page: 411 },
    { number: 32, nameAr: 'السَّجْدَة', nameEn: 'As-Sajdah', meaning: 'The Prostration', ayahs: 30, type: 'Meccan', page: 415 },
    { number: 33, nameAr: 'الأَحْزَاب', nameEn: 'Al-Ahzab', meaning: 'The Combined Forces', ayahs: 73, type: 'Medinan', page: 418 },
    { number: 34, nameAr: 'سَبَأ', nameEn: 'Saba', meaning: 'Sheba', ayahs: 54, type: 'Meccan', page: 428 },
    { number: 35, nameAr: 'فَاطِر', nameEn: 'Fatir', meaning: 'Originator', ayahs: 45, type: 'Meccan', page: 434 },
    { number: 36, nameAr: 'يس', nameEn: 'Ya-Sin', meaning: 'Ya-Sin', ayahs: 83, type: 'Meccan', page: 440 },
    { number: 37, nameAr: 'الصَّافَّات', nameEn: 'As-Saffat', meaning: 'Those who set the Ranks', ayahs: 182, type: 'Meccan', page: 446 },
    { number: 38, nameAr: 'ص', nameEn: 'Sad', meaning: 'The Letter Sad', ayahs: 88, type: 'Meccan', page: 453 },
    { number: 39, nameAr: 'الزُّمَر', nameEn: 'Az-Zumar', meaning: 'The Troops', ayahs: 75, type: 'Meccan', page: 458 },
    { number: 40, nameAr: 'غَافِر', nameEn: 'Ghafir', meaning: 'The Forgiver', ayahs: 85, type: 'Meccan', page: 467 },
    { number: 41, nameAr: 'فُصِّلَت', nameEn: 'Fussilat', meaning: 'Explained in Detail', ayahs: 54, type: 'Meccan', page: 477 },
    { number: 42, nameAr: 'الشُّورَى', nameEn: 'Ash-Shura', meaning: 'The Consultation', ayahs: 53, type: 'Meccan', page: 483 },
    { number: 43, nameAr: 'الزُّخْرُف', nameEn: 'Az-Zukhruf', meaning: 'The Ornaments of Gold', ayahs: 89, type: 'Meccan', page: 489 },
    { number: 44, nameAr: 'الدُّخَان', nameEn: 'Ad-Dukhan', meaning: 'The Smoke', ayahs: 59, type: 'Meccan', page: 496 },
    { number: 45, nameAr: 'الجَاثِيَة', nameEn: 'Al-Jathiyah', meaning: 'The Crouching', ayahs: 37, type: 'Meccan', page: 499 },
    { number: 46, nameAr: 'الأَحْقَاف', nameEn: 'Al-Ahqaf', meaning: 'The Wind-Curved Sandhills', ayahs: 35, type: 'Meccan', page: 502 },
    { number: 47, nameAr: 'مُحَمَّد', nameEn: 'Muhammad', meaning: 'Muhammad', ayahs: 38, type: 'Medinan', page: 507 },
    { number: 48, nameAr: 'الفَتْح', nameEn: 'Al-Fath', meaning: 'The Victory', ayahs: 29, type: 'Medinan', page: 511 },
    { number: 49, nameAr: 'الحُجُرَات', nameEn: 'Al-Hujurat', meaning: 'The Rooms', ayahs: 18, type: 'Medinan', page: 515 },
    { number: 50, nameAr: 'ق', nameEn: 'Qaf', meaning: 'The Letter Qaf', ayahs: 45, type: 'Meccan', page: 518 },
    { number: 51, nameAr: 'الذَّارِيَات', nameEn: 'Adh-Dhariyat', meaning: 'The Winnowing Winds', ayahs: 60, type: 'Meccan', page: 520 },
    { number: 52, nameAr: 'الطُّور', nameEn: 'At-Tur', meaning: 'The Mount', ayahs: 49, type: 'Meccan', page: 523 },
    { number: 53, nameAr: 'النَّجْم', nameEn: 'An-Najm', meaning: 'The Star', ayahs: 62, type: 'Meccan', page: 526 },
    { number: 54, nameAr: 'القَمَر', nameEn: 'Al-Qamar', meaning: 'The Moon', ayahs: 55, type: 'Meccan', page: 528 },
    { number: 55, nameAr: 'الرَّحْمَن', nameEn: 'Ar-Rahman', meaning: 'The Beneficent', ayahs: 78, type: 'Medinan', page: 531 },
    { number: 56, nameAr: 'الوَاقِعَة', nameEn: 'Al-Waqi\'ah', meaning: 'The Inevitable', ayahs: 96, type: 'Meccan', page: 534 },
    { number: 57, nameAr: 'الحَدِيد', nameEn: 'Al-Hadid', meaning: 'The Iron', ayahs: 29, type: 'Medinan', page: 537 },
    { number: 58, nameAr: 'المُجَادِلَة', nameEn: 'Al-Mujadila', meaning: 'The Pleading Woman', ayahs: 22, type: 'Medinan', page: 542 },
    { number: 59, nameAr: 'الحَشْر', nameEn: 'Al-Hashr', meaning: 'The Exile', ayahs: 24, type: 'Medinan', page: 545 },
    { number: 60, nameAr: 'المُمْتَحَنَة', nameEn: 'Al-Mumtahanah', meaning: 'She that is to be examined', ayahs: 13, type: 'Medinan', page: 549 },
    { number: 61, nameAr: 'الصَّفّ', nameEn: 'As-Saff', meaning: 'The Ranks', ayahs: 14, type: 'Medinan', page: 551 },
    { number: 62, nameAr: 'الجُمُعَة', nameEn: 'Al-Jumu\'ah', meaning: 'The Congregation, Friday', ayahs: 11, type: 'Medinan', page: 553 },
    { number: 63, nameAr: 'المُنَافِقُون', nameEn: 'Al-Munafiqun', meaning: 'The Hypocrites', ayahs: 11, type: 'Medinan', page: 554 },
    { number: 64, nameAr: 'التَّغَابُن', nameEn: 'At-Taghabun', meaning: 'The Mutual Disillusion', ayahs: 18, type: 'Medinan', page: 556 },
    { number: 65, nameAr: 'الطَّلَاق', nameEn: 'At-Talaq', meaning: 'The Divorce', ayahs: 12, type: 'Medinan', page: 558 },
    { number: 66, nameAr: 'التَّحْرِيم', nameEn: 'At-Tahrim', meaning: 'The Prohibition', ayahs: 12, type: 'Medinan', page: 560 },
    { number: 67, nameAr: 'المُلْك', nameEn: 'Al-Mulk', meaning: 'The Sovereignty', ayahs: 30, type: 'Meccan', page: 562 },
    { number: 68, nameAr: 'القَلَم', nameEn: 'Al-Qalam', meaning: 'The Pen', ayahs: 52, type: 'Meccan', page: 564 },
    { number: 69, nameAr: 'الحَاقَّة', nameEn: 'Al-Haqqah', meaning: 'The Inevitable Truth', ayahs: 52, type: 'Meccan', page: 566 },
    { number: 70, nameAr: 'المَعَارِج', nameEn: 'Al-Ma\'arij', meaning: 'The Ascending Stairways', ayahs: 44, type: 'Meccan', page: 568 },
    { number: 71, nameAr: 'نُوح', nameEn: 'Nuh', meaning: 'Noah', ayahs: 28, type: 'Meccan', page: 570 },
    { number: 72, nameAr: 'الجِنّ', nameEn: 'Al-Jinn', meaning: 'The Jinn', ayahs: 28, type: 'Meccan', page: 572 },
    { number: 73, nameAr: 'المُزَّمِّل', nameEn: 'Al-Muzzammil', meaning: 'The Enshrouded One', ayahs: 20, type: 'Meccan', page: 574 },
    { number: 74, nameAr: 'المُدَّثِّر', nameEn: 'Al-Muddaththir', meaning: 'The Cloaked One', ayahs: 56, type: 'Meccan', page: 575 },
    { number: 75, nameAr: 'القِيَامَة', nameEn: 'Al-Qiyamah', meaning: 'The Resurrection', ayahs: 40, type: 'Meccan', page: 577 },
    { number: 76, nameAr: 'الإِنْسَان', nameEn: 'Al-Insan', meaning: 'The Human', ayahs: 31, type: 'Medinan', page: 578 },
    { number: 77, nameAr: 'المُرْسَلَات', nameEn: 'Al-Mursalat', meaning: 'The Emissaries', ayahs: 50, type: 'Meccan', page: 580 },
    { number: 78, nameAr: 'النَّبَأ', nameEn: 'An-Naba', meaning: 'The Tidings', ayahs: 40, type: 'Meccan', page: 582 },
    { number: 79, nameAr: 'النَّازِعَات', nameEn: 'An-Nazi\'at', meaning: 'Those who drag forth', ayahs: 46, type: 'Meccan', page: 583 },
    { number: 80, nameAr: 'عَبَسَ', nameEn: '\'Abasa', meaning: 'He Frowned', ayahs: 42, type: 'Meccan', page: 585 },
    { number: 81, nameAr: 'التَّكْوِير', nameEn: 'At-Takwir', meaning: 'The Overthrowing', ayahs: 29, type: 'Meccan', page: 586 },
    { number: 82, nameAr: 'الانْفِطَار', nameEn: 'Al-Infitar', meaning: 'The Cleaving', ayahs: 19, type: 'Meccan', page: 587 },
    { number: 83, nameAr: 'المُطَفِّفِين', nameEn: 'Al-Mutaffifin', meaning: 'The Defrauding', ayahs: 36, type: 'Meccan', page: 587 },
    { number: 84, nameAr: 'الانْشِقَاق', nameEn: 'Al-Inshiqaq', meaning: 'The Splitting Open', ayahs: 25, type: 'Meccan', page: 589 },
    { number: 85, nameAr: 'البُرُوج', nameEn: 'Al-Buruj', meaning: 'The Mansions of the Stars', ayahs: 22, type: 'Meccan', page: 590 },
    { number: 86, nameAr: 'الطَّارِق', nameEn: 'At-Tariq', meaning: 'The Morning Star', ayahs: 17, type: 'Meccan', page: 591 },
    { number: 87, nameAr: 'الأَعْلَى', nameEn: 'Al-A\'la', meaning: 'The Most High', ayahs: 19, type: 'Meccan', page: 591 },
    { number: 88, nameAr: 'الغَاشِيَة', nameEn: 'Al-Ghashiyah', meaning: 'The Overwhelming', ayahs: 26, type: 'Meccan', page: 592 },
    { number: 89, nameAr: 'الفَجْر', nameEn: 'Al-Fajr', meaning: 'The Dawn', ayahs: 30, type: 'Meccan', page: 593 },
    { number: 90, nameAr: 'البَلَد', nameEn: 'Al-Balad', meaning: 'The City', ayahs: 20, type: 'Meccan', page: 594 },
    { number: 91, nameAr: 'الشَّمْس', nameEn: 'Ash-Shams', meaning: 'The Sun', ayahs: 15, type: 'Meccan', page: 595 },
    { number: 92, nameAr: 'اللَّيْل', nameEn: 'Al-Layl', meaning: 'The Night', ayahs: 21, type: 'Meccan', page: 595 },
    { number: 93, nameAr: 'الضُّحَى', nameEn: 'Ad-Duha', meaning: 'The Morning Hours', ayahs: 11, type: 'Meccan', page: 596 },
    { number: 94, nameAr: 'الشَّرْح', nameEn: 'Ash-Sharh', meaning: 'The Relief', ayahs: 8, type: 'Meccan', page: 596 },
    { number: 95, nameAr: 'التِّين', nameEn: 'At-Tin', meaning: 'The Fig', ayahs: 8, type: 'Meccan', page: 597 },
    { number: 96, nameAr: 'العَلَق', nameEn: 'Al-\'Alaq', meaning: 'The Clot', ayahs: 19, type: 'Meccan', page: 597 },
    { number: 97, nameAr: 'القَدْر', nameEn: 'Al-Qadr', meaning: 'The Power, Fate', ayahs: 5, type: 'Meccan', page: 598 },
    { number: 98, nameAr: 'البَيِّنَة', nameEn: 'Al-Bayyinah', meaning: 'The Clear Proof', ayahs: 8, type: 'Medinan', page: 598 },
    { number: 99, nameAr: 'الزَّلْزَلَة', nameEn: 'Az-Zalzalah', meaning: 'The Earthquake', ayahs: 8, type: 'Medinan', page: 599 },
    { number: 100, nameAr: 'العَادِيَات', nameEn: 'Al-\'Adiyat', meaning: 'The Courser', ayahs: 11, type: 'Meccan', page: 599 },
    { number: 101, nameAr: 'القَارِعَة', nameEn: 'Al-Qari\'ah', meaning: 'The Calamity', ayahs: 11, type: 'Meccan', page: 600 },
    { number: 102, nameAr: 'التَّكَاثُر', nameEn: 'At-Takathur', meaning: 'The Rivalry in world increase', ayahs: 8, type: 'Meccan', page: 600 },
    { number: 103, nameAr: 'العَصْر', nameEn: 'Al-\'Asr', meaning: 'The Declining Day, Time', ayahs: 3, type: 'Meccan', page: 601 },
    { number: 104, nameAr: 'الهُمَزَة', nameEn: 'Al-Humazah', meaning: 'The Traducer', ayahs: 9, type: 'Meccan', page: 601 },
    { number: 105, nameAr: 'الفِيل', nameEn: 'Al-Fil', meaning: 'The Elephant', ayahs: 5, type: 'Meccan', page: 601 },
    { number: 106, nameAr: 'قُرَيْش', nameEn: 'Quraysh', meaning: 'Quraysh', ayahs: 4, type: 'Meccan', page: 602 },
    { number: 107, nameAr: 'المَاعُون', nameEn: 'Al-Ma\'un', meaning: 'Small Kindnesses', ayahs: 7, type: 'Meccan', page: 602 },
    { number: 108, nameAr: 'الكَوْثَر', nameEn: 'Al-Kawthar', meaning: 'The Abundance', ayahs: 3, type: 'Meccan', page: 602 },
    { number: 109, nameAr: 'الكَافِرُون', nameEn: 'Al-Kafirun', meaning: 'The Disbelievers', ayahs: 6, type: 'Meccan', page: 603 },
    { number: 110, nameAr: 'النَّصْر', nameEn: 'An-Nasr', meaning: 'The Divine Support', ayahs: 3, type: 'Medinan', page: 603 },
    { number: 111, nameAr: 'المَسَد', nameEn: 'Al-Masad', meaning: 'The Palm Fiber', ayahs: 5, type: 'Meccan', page: 603 },
    { number: 112, nameAr: 'الإِخْلَاص', nameEn: 'Al-Ikhlas', meaning: 'The Sincerity', ayahs: 4, type: 'Meccan', page: 604 },
    { number: 113, nameAr: 'الفَلَق', nameEn: 'Al-Falaq', meaning: 'The Daybreak', ayahs: 5, type: 'Meccan', page: 604 },
    { number: 114, nameAr: 'النَّاس', nameEn: 'An-Nas', meaning: 'Mankind', ayahs: 6, type: 'Meccan', page: 604 }
];

// Offline Fallback Verses for Key Essential Surahs
const OFFLINE_SURAHS = {
    1: {
        number: 1,
        nameAr: 'الفَاتِحَة',
        nameEn: 'Al-Fatihah',
        bismillah: false,
        verses: [
            { numberInSurah: 1, arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', translation: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.' },
            { numberInSurah: 2, arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', translation: '[All] praise is [due] to Allah, Lord of the worlds -' },
            { numberInSurah: 3, arabic: 'الرَّحْمَنِ الرَّحِيمِ', translation: 'The Entirely Merciful, the Especially Merciful,' },
            { numberInSurah: 4, arabic: 'مَالِكِ يَوْمِ الدِّينِ', translation: 'Sovereign of the Day of Recompense.' },
            { numberInSurah: 5, arabic: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', translation: 'It is You we worship and You we ask for help.' },
            { numberInSurah: 6, arabic: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', translation: 'Guide us to the straight path -' },
            { numberInSurah: 7, arabic: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', translation: 'The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.' }
        ]
    },
    112: {
        number: 112,
        nameAr: 'الإِخْلَاص',
        nameEn: 'Al-Ikhlas',
        bismillah: true,
        verses: [
            { numberInSurah: 1, arabic: 'قُلْ هُوَ اللَّهُ أَحَدٌ', translation: 'Say, "He is Allah, [who is] One,' },
            { numberInSurah: 2, arabic: 'اللَّهُ الصَّمَدُ', translation: 'Allah, the Eternal Refuge.' },
            { numberInSurah: 3, arabic: 'لَمْ يَلِدْ وَلَمْ يُولَدْ', translation: 'He neither begets nor is born,' },
            { numberInSurah: 4, arabic: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', translation: 'Nor is there to Him any equivalent."' }
        ]
    },
    113: {
        number: 113,
        nameAr: 'الفَلَق',
        nameEn: 'Al-Falaq',
        bismillah: true,
        verses: [
            { numberInSurah: 1, arabic: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ', translation: 'Say, "I seek refuge in the Lord of daybreak' },
            { numberInSurah: 2, arabic: 'مِن شَرِّ مَا خَلَقَ', translation: 'From the evil of that which He created' },
            { numberInSurah: 3, arabic: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ', translation: 'And from the evil of darkness when it settles' },
            { numberInSurah: 4, arabic: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ', translation: 'And from the evil of the blowers in knots' },
            { numberInSurah: 5, arabic: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', translation: 'And from the evil of an envier when he envies."' }
        ]
    },
    114: {
        number: 114,
        nameAr: 'النَّاس',
        nameEn: 'An-Nas',
        bismillah: true,
        verses: [
            { numberInSurah: 1, arabic: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ', translation: 'Say, "I seek refuge in the Lord of mankind,' },
            { numberInSurah: 2, arabic: 'مَلِكِ النَّاسِ', translation: 'The Sovereign of mankind.' },
            { numberInSurah: 3, arabic: 'إِلَهِ النَّاسِ', translation: 'The God of mankind,' },
            { numberInSurah: 4, arabic: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ', translation: 'From the evil of the retreating whisperer -' },
            { numberInSurah: 5, arabic: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ', translation: 'Who whispers [evil] into the breasts of mankind -' },
            { numberInSurah: 6, arabic: 'مِنَ الْجِنَّةِ وَالنَّاسِ', translation: 'From among the jinn and mankind."' }
        ]
    },
    67: {
        number: 67,
        nameAr: 'المُلْك',
        nameEn: 'Al-Mulk',
        bismillah: true,
        verses: [
            { numberInSurah: 1, arabic: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', translation: 'Blessed is He in whose hand is dominion, and He is over all things competent -' },
            { numberInSurah: 2, arabic: 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ', translation: '[He] who created death and life to test you [as to] which of you is best in deed - and He is the Exalted in Might, the Forgiving -' },
            { numberInSurah: 3, arabic: 'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ', translation: '[And] who created seven heavens in layers. You see not in the creation of the Most Merciful any inconsistency. So return [your] vision [to the sky]; do you see any breaks?' },
            { numberInSurah: 4, arabic: 'ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ', translation: 'Then return [your] vision twice again. [Your] vision will return to you humbled while it is fatigued.' },
            { numberInSurah: 5, arabic: 'وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ ۖ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ', translation: 'And We have certainly beautified the nearest heaven with stars and have made [from] them what is thrown at the devils and have prepared for them the punishment of the Blaze.' }
        ]
    },
    108: {
        number: 108,
        nameAr: 'الكَوْثَر',
        nameEn: 'Al-Kawthar',
        bismillah: true,
        verses: [
            { numberInSurah: 1, arabic: 'إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ', translation: 'Indeed, We have granted you, [O Muhammad], al-Kawthar.' },
            { numberInSurah: 2, arabic: 'فَصَلِّ لِرَبِّكَ وَانْحَرْ', translation: 'So pray to your Lord and sacrifice [to Him alone].' },
            { numberInSurah: 3, arabic: 'إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ', translation: 'Indeed, your enemy is the one cut off.' }
        ]
    }
};

// Reciters list
const QURAN_RECITERS = [
    { id: 'Alafasy_128kbps', nameAr: 'مشاري راشد العفاسي', nameEn: 'Mishary Rashid Alafasy', subFolder: 'Alafasy_128kbps' },
    { id: 'Abdul_Basit_Murattal_192kbps', nameAr: 'عبد الباسط عبد الصمد (مرتل)', nameEn: 'Abdul Basit Murattal', subFolder: 'Abdul_Basit_Murattal_192kbps' },
    { id: 'Ghamadi_40kbps', nameAr: 'سعد الغامدي', nameEn: 'Saad Al-Ghamdi', subFolder: 'Ghamadi_40kbps' },
    { id: 'Husary_128kbps', nameAr: 'محمود خليل الحصري', nameEn: 'Mahmoud Khalil Al-Husary', subFolder: 'Husary_128kbps' },
    { id: 'Abu_Bakr_Ash-Shaatree_128kbps', nameAr: 'أبو بكر الشاطري', nameEn: 'Abu Bakr Al-Shatri', subFolder: 'Abu_Bakr_Ash-Shaatree_128kbps' }
];

class QuranService {
    constructor() {
        this.cache = new Map();
        this.currentReciter = 'Alafasy_128kbps';
    }

    /**
     * Get Verse Audio URL from EveryAyah CDN
     */
    getAyahAudioUrl(surahNumber, ayahNumber, reciterId = null) {
        let reciter = reciterId || this.currentReciter;
        let sStr = String(surahNumber).padStart(3, '0');
        let aStr = String(ayahNumber).padStart(3, '0');
        return `https://everyayah.com/data/${reciter}/${sStr}${aStr}.mp3`;
    }

    /**
     * Fetch complete Surah verses (Arabic + English) with cache and offline fallback
     */
    async getSurah(surahNumber) {
        let num = parseInt(surahNumber, 10);
        if (this.cache.has(num)) {
            return this.cache.get(num);
        }

        // Try local storage cache
        let stored = localStorage.getItem(`quran_surah_${num}`);
        if (stored) {
            try {
                let parsed = JSON.parse(stored);
                this.cache.set(num, parsed);
                return parsed;
            } catch (e) {}
        }

        // Try fetching from Al-Quran Cloud API
        try {
            let res = await fetch(`https://api.alquran.cloud/v1/surah/${num}/editions/quran-uthmani,en.sahih`);
            if (res.ok) {
                let json = await res.json();
                if (json.code === 200 && json.data && json.data.length >= 2) {
                    let arEd = json.data[0];
                    let enEd = json.data[1];

                    let verses = arEd.ayahs.map((arAyah, idx) => {
                        let enAyah = enEd.ayahs[idx] || {};
                        let arabicText = arAyah.text;

                        // Clean out repetitive Bismillah prefix except for Surah Al-Fatihah
                        if (num !== 1 && num !== 9 && idx === 0 && arabicText.startsWith('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')) {
                            arabicText = arabicText.replace('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', '').trim();
                        }

                        return {
                            numberInSurah: arAyah.numberInSurah,
                            numberGlobal: arAyah.number,
                            arabic: arabicText,
                            translation: enAyah.text || ''
                        };
                    });

                    let surahObj = {
                        number: num,
                        nameAr: arEd.name,
                        nameEn: arEd.englishName,
                        meaning: arEd.englishNameTranslation,
                        ayahs: arEd.numberOfAyahs,
                        type: arEd.revelationType === 'Meccan' ? 'Meccan' : 'Medinan',
                        bismillah: num !== 1 && num !== 9,
                        verses: verses
                    };

                    this.cache.set(num, surahObj);
                    try {
                        localStorage.setItem(`quran_surah_${num}`, JSON.stringify(surahObj));
                    } catch (e) {}
                    return surahObj;
                }
            }
        } catch (err) {
            console.warn(`Online fetch for Surah ${num} failed, checking offline fallback:`, err);
        }

        // Use offline fallback if available
        if (OFFLINE_SURAHS[num]) {
            let meta = QURAN_SURAHS.find(s => s.number === num);
            let fallback = {
                ...OFFLINE_SURAHS[num],
                meaning: meta ? meta.meaning : '',
                type: meta ? meta.type : 'Meccan',
                ayahs: meta ? meta.ayahs : OFFLINE_SURAHS[num].verses.length
            };
            this.cache.set(num, fallback);
            return fallback;
        }

        // Generic stub if offline and not in key offline surahs
        let meta = QURAN_SURAHS.find(s => s.number === num) || { nameAr: `سورة ${num}`, nameEn: `Surah ${num}`, ayahs: 7 };
        return {
            number: num,
            nameAr: meta.nameAr,
            nameEn: meta.nameEn,
            meaning: meta.meaning || '',
            ayahs: meta.ayahs,
            type: meta.type || 'Meccan',
            bismillah: num !== 1 && num !== 9,
            isPartialOffline: true,
            verses: [
                {
                    numberInSurah: 1,
                    arabic: `جاري الاتصال لتحميل آيات سورة ${meta.nameAr} كاملة بالرسم العثماني والتلاوة...`,
                    translation: `Connecting to load all verses for Surah ${meta.nameEn} with Uthmani script and audio recitation.`
                }
            ]
        };
    }
}

window.QURAN_SURAHS = QURAN_SURAHS;
window.QURAN_RECITERS = QURAN_RECITERS;
window.QuranEngine = new QuranService();

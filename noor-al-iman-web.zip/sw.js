/**
 * Noor Al-Iman - Service Worker
 * Offline Caching & Background Notifications Support
 */

const CACHE_NAME = 'noor-al-iman-v1';
const ASSETS_TO_CACHE = [
    './',
    './index.html',
    './manifest.json',
    './css/styles.css',
    './js/prayer-times.js',
    './js/adhkar-data.js',
    './js/quran-data.js',
    './js/audio-service.js',
    './js/app.js',
    './assets/icon-192.png',
    './assets/icon-512.png',
    './assets/favicon.png'
];

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(ASSETS_TO_CACHE);
        })
    );
    self.skipWaiting();
});

self.addEventListener('activate', (e) => {
    e.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.map((k) => {
                    if (k !== CACHE_NAME) {
                        return caches.delete(k);
                    }
                })
            );
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', (e) => {
    // Cache-first strategy for static assets, network fallback
    e.respondWith(
        caches.match(e.request).then((cachedResponse) => {
            if (cachedResponse) {
                return cachedResponse;
            }
            return fetch(e.request).then((networkResponse) => {
                if (networkResponse && networkResponse.status === 200 && e.request.method === 'GET') {
                    const responseClone = networkResponse.clone();
                    caches.open(CACHE_NAME).then((cache) => {
                        // Do not cache external audio streams to preserve storage
                        if (!e.request.url.includes('.mp3')) {
                            cache.put(e.request, responseClone);
                        }
                    });
                }
                return networkResponse;
            }).catch(() => {
                // If offline and request is HTML, return cached index.html
                if (e.request.headers.get('accept').includes('text/html')) {
                    return caches.match('./index.html');
                }
            });
        })
    );
});

// Push notification listener
self.addEventListener('push', (e) => {
    const data = e.data ? e.data.json() : {};
    const title = data.title || 'حان موعد الصلاة - نور الإيمان';
    const options = {
        body: data.body || 'حي على الصلاة .. حي على الفلاح',
        icon: './assets/icon-192.png',
        badge: './assets/favicon.png',
        vibrate: [200, 100, 200],
        data: {
            url: './index.html'
        }
    };
    e.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (e) => {
    e.notification.close();
    e.waitUntil(
        clients.matchAll({ type: 'window' }).then((clientList) => {
            for (let i = 0; i < clientList.length; i++) {
                let client = clientList[i];
                if (client.url.includes('index.html') && 'focus' in client) {
                    return client.focus();
                }
            }
            if (clients.openWindow) {
                return clients.openWindow('./index.html');
            }
        })
    );
});
